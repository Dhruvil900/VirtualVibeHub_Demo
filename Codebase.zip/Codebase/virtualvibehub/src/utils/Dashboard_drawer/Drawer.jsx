import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import logo from "../../assets/bird.png";
import calender from "../../assets/calender.png";
import Search from "../../components/Search/search";
function Drawer() {
  const date = new Date();
  const day =
    date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();

  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);
  return (
    <div className="container">
      <div className="row" style={{ display: "flex", alignItems: "center" }}>
        <div className="col-7">
          <Search />
        </div>
        <div className="col-3" style={{display:"flex", justifyContent:"center"}}>
          <img src={calender} alt="" style={{ width: "30px " }} /> {day} {"  "}
          {time.toTimeString().split(" ")[0]}
        </div>
        <div className="col-2">
          <Link to="/" style={{ textDecoration: "none" }}>
            <img src={logo} alt="" style={{ width: "30px" }} />{" "}
            <span className="spantext">VirtualVibeHub</span>{" "}
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Drawer;
