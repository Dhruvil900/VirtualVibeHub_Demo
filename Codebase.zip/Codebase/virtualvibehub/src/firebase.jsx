// Import the functions you need from the SDKs you need
import { getAuth } from "firebase/auth";
import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/storage";

// Required for side-effects
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDdiwCIEFchhUuSseiYZOrwhq9-GyrEvmg",
  authDomain: "virtualvibehub.firebaseapp.com",
  projectId: "virtualvibehub",
  storageBucket: "virtualvibehub.appspot.com",
  messagingSenderId: "902318806092",
  appId: "1:902318806092:web:611faf7d4e4e2f6385d0e9",
  measurementId: "G-B5FSLGS2WL",
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = firebase.firestore();
export const storage = firebase.storage();