import React from "react";
import { Route, Routes, useLocation, useHistory } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar/Navbar";
import Event from "./pages/Event/Event";
import Home from "./pages/Home/Home";
import Virtual_space from "./pages/Virtual Space/Virtual_space";
import ContactUs from "./pages/ContactUs/Contact";
import Signinup from "../src/components/auth/LoginSign";
import { useEffect } from "react";
import Footer from "./components/Footer/Footer";
import EventDetail from "./pages/Event_details/EventDetail";
import About from "./pages/about/about";
import Userdashboard from "./pages/Userdashboard/Userdashboard";
import Eventfillup from "./pages/Eventfillup/Eventfillup";
import Dashboard from "./pages/Userdashboard/Dashboard/Dashboard";
import Events from "./pages/Userdashboard/Events/Events";
import Live from "./pages/Userdashboard/Live_events/Live";
import History from "./pages/Userdashboard/History/History";
import Imageadd from "./pages/Imageadd/Image";
import Eventadmin from "./pages/EventAdmindashboard/Eventadminevent/Event_admin";
import People from "./pages/EventAdmindashboard/Eventadmindpeople/people";
import Poll from "./pages/EventAdmindashboard/Eventadmindpoll/Poll";
import Createevent from "./pages/EventAdmindashboard/Eventadmindcreateevent/Createevent";
import Eventadmindashboard from "./pages/EventAdmindashboard/Eventadmindashboard";
import TimeRange from "./Time";
import Manageevent from "./pages/EventAdmindashboard/Eventadmindcreateevent/Manageevent";
import Usermanage from "./pages/EventAdmindashboard/Usermanagement/Usermanage";
import Room from "./pages/Userdashboard/Live_events/livestreaming";
import { IdProvider } from "./Context/usercontext";

function App() {
  // const current_theme = localStorage.getItem("current_theme");
  // const [theme, settheme] = React.useState(
  //   current_theme ? current_theme : "white"
  // );
  // useEffect(() => {
  //   localStorage.setItem("current_theme", theme);
  // }, [theme]);
  // const history=useHistory()
  // console.log(history)
  let location = useLocation();
  useEffect(() => {
    console.log(location);
  }, [location]);
  return (
    <div>
      <IdProvider>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/event" element={<Event />} />
          <Route path="/virtual_space" element={<Virtual_space />} />
          <Route path="/login" element={<Signinup />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/details" element={<EventDetail />} />
          <Route path="/about" element={<About />} />
          <Route path="/Attendeedashboard" element={<Userdashboard />} />
          <Route path="/eventfillup" element={<Eventfillup />} />
          <Route path="/user-dashboard" element={<Dashboard />}></Route>
          <Route path="/user-event" element={<Events />}></Route>
          <Route path="/user-live" element={<Live />}></Route>
          <Route path="/user-history" element={<History />}></Route>
          <Route path="/image" element={<Imageadd />}></Route>
          <Route
            path="/admin-dashboard"
            element={<Eventadmindashboard />}
          ></Route>
          <Route path="/Eventadmin-event" element={<Eventadmin />}></Route>
          <Route path="/Eventadmin-people" element={<People />}></Route>
          <Route path="/Eventadmin-poll" element={<Poll />}></Route>
          <Route
            path="/Eventadmin-createevent"
            element={<Createevent />}
          ></Route>
          <Route
            path="/Eventadmin-manageevent"
            element={<Manageevent />}
          ></Route>
          <Route path="/Eventadmin-manageuser" element={<Usermanage />}></Route>
          <Route path="/livestreaming/:id" element={<Room />}></Route>
        </Routes>
      </IdProvider>
    </div>
  );
}

export default App;
