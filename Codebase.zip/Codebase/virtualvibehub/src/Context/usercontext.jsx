// IdContext.js
import React, { createContext, useState } from 'react';

const IdContext = createContext();

export const IdProvider = ({ children }) => {
  const [eid, setId] = useState("");

  return (
    <IdContext.Provider value={{ eid, setId }}>
      {children}
    </IdContext.Provider>
  );
};

export default IdContext;
