import React from "react";
import Navbar from "../../components/Navbar/Navbar";

const Virtual_space = () => {
  return (
    <div>
      <Navbar />{" "}
    </div>
  );
};

export default Virtual_space;
