import React, { useEffect, useState } from "react";
import "./eventdetails.css";
import Footer from "../../components/Footer/Footer";
import Navbar from "../../components/Navbar/Navbar";
import { useLocation } from "react-router-dom";
import { collection, doc, getDoc, getDocs } from "firebase/firestore";
import { db } from "../../firebase";
import { Carousel } from "react-bootstrap";
function EventDetail() {
  const location = useLocation();
  const id = location.state;
  const [fetchdata, setFetchdata] = useState([]);
  const [imgs, setImgs] = useState([]);
  const [simgs, setSimgs] = useState([]);
  const [spimgs, setSpimgs] = useState([]);
  let Multipleimgs, Sponsersimg,Speakerimg;
  let date, stime, etime, time, mainimg;
  const fetch = async () => {
    const snapshot = await getDoc(doc(db, "events", id));
    const fetchdata = {
      id: snapshot.id,
      ...snapshot.data(),
    };
    setFetchdata(fetchdata);
    console.log(fetchdata);
    console.log(fetchdata.AdditionalImages);
    Multipleimgs = fetchdata.AdditionalImages;
    date = fetchdata.Date;
    stime = fetchdata.StartTime;
    etime = fetchdata.EndTime;
    time = stime + " - " + etime;
    mainimg = fetchdata.MainImage;
    console.log(fetchdata.SponsersImage);
    Sponsersimg = fetchdata.SponsersImage;
    Speakerimg = fetchdata.SpeakerImage;
    const ImagesEvent = () => {
      let sampleimgs = [];
      // sampleimgs.push(mainimg);
      sampleimgs.push(mainimg);
      Multipleimgs.forEach((img) => {
        sampleimgs.push(img);
      });
      // for(let i=0;i<addimgs.length;i++){
      //   sampleimgs.push(fetchdata.Images[i])
      // }
      console.log(sampleimgs);
      setImgs(sampleimgs);
      console.log(imgs);
    };
    const sponserimg = () => {
      let Simg = [];
      // sampleimgs.push(mainimg);
      Sponsersimg.forEach((img) => {
        Simg.push(img);
      });
      // for(let i=0;i<addimgs.length;i++){
      //   sampleimgs.push(fetchdata.Images[i])
      // }
      setSimgs(Simg);
      console.log(Simg);
    };
    const speakerimg = () => {
      let Spimg = [];
      // sampleimgs.push(mainimg);
      Speakerimg.forEach((img) => {
        Spimg.push(img);
      });
      // for(let i=0;i<addimgs.length;i++){
      //   sampleimgs.push(fetchdata.Images[i])
      // }
      setSpimgs(Spimg);
      console.log(Spimg);
    };
    ImagesEvent();
    sponserimg();
    speakerimg();
  };
  useEffect(() => {
    fetch();
  }, []);
  return (
    <div>
      <Navbar />
      <div className="container-fluid">
        <div className="row">
          <div className="col-3">
            <div
              style={{
                height: "94vh",
                overflow: "auto",
                borderRight: "3px solid black",
                borderBottom: "3px solid black",
                borderBottomRightRadius: "4  px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              {imgs.map((imgs) => {
                return (
                  <div
                    style={{
                      height: "250px",
                      marginBottom: "10px",
                      alignItems: "center",
                    }}
                  >
                    <img src={imgs} alt="" className="image" />
                  </div>
                );
              })}
            </div>
          </div>
          <div className="col-9">
            <div>
              <h4>Event Name:- </h4>
              {fetchdata.EventName}
            </div>
            <div>
              <h4>Event Description:- </h4>
              {fetchdata.EventDescriptionDetail}
            </div>
            <div>
              <h4>Date and Time:- </h4>
              {date} {"    "} &ensp;{time}{" "}
            </div>
            
            <div>
              <h4>Event Type:- </h4>
              {fetchdata.EventType}
            </div>
            <div>
              <h4>Venue:- </h4>
              {fetchdata.Venue}
            </div>
            <div>
              <h4>Registration Fee:- </h4>
              {fetchdata.Fee}
            </div>
            <div>
              <h4>Contact:- </h4>
              {fetchdata.Contact}
            </div>
            <div>
              <h4>Link of social media:- </h4>
              {fetchdata.Message} <br />
              Linkdin :- {fetchdata.Linkdin} <br />
              Facebook :- {fetchdata.Facebook} <br />
              Twitter :- {fetchdata.Twitter}
              <br />
              Instagram :- {fetchdata.Instagram}
              <br />
            </div>
            <div>
              <h4>Type of Event:- </h4>
              {fetchdata.EventType}
            </div>
            <div className="row">
              <div className="col-8">
                <h4 style={{ textDecoration: "underline" }}>Sponsers :-</h4>
                {fetchdata.Sponsers}
                <div className="row m-0 p-0 ">
                  <h6
                    className="m-0 p-0 mb-2"
                    style={{ textDecoration: "underline" }}
                  >
                    Sponsers Gallery :-{" "}
                  </h6>
                  <div
                    className=" p-3 mb-3"
                    style={{
                      border: "2px solid black",
                      height: "250px",
                      borderRadius: "5px",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <div className="sponsers"
                      style={{
                        overflowX: "auto",
                        maxHeight: "200px",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {simgs.map((item) => {
                        return (
                          <img
                            src={item}
                            alt=""
                            style={{
                              height: "180px",
                              width: "180px",
                              marginRight: "10px",
                            }}
                          />
                        );
                      })}
                      {simgs.map((item) => {
                        return (
                          <img
                            src={item}
                            alt=""
                            style={{
                              height: "180px",
                              width: "180px",
                              display: "inline-block",
                              marginRight: "10px",
                            }}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-4">
                <h4 style={{ textDecoration: "underline" }}>Speaker (s)</h4>
                <div>
              {fetchdata.SpeakerName}
            </div>
                <div
                  id="carouselExampleIndicators"
                  class="carousel slide  mt-3 pt-2"
                >
                  <Carousel
                    style={{
                      transition: "0.8s",
                      border: "2px solid #29485b",
                      borderRadius: "5px",
                      height: "250px",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    {spimgs.map((item) => {
                      return (
                        <Carousel.Item>
                          <img
                            className="d-block w-100 "
                            src={item}
                            style={{ height: "200px", width: "200px" }}
                          />
                        </Carousel.Item>
                      );
                    })}
                  </Carousel>
                </div>
              </div>
            </div>
            <div className="row mb-4">
              <div className="col-4">
                <h4>Register yourself in event :- </h4>
              </div>
              <div className="col-6">
                <button className="btn w-auto "> Register</button>{" "}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default EventDetail;
