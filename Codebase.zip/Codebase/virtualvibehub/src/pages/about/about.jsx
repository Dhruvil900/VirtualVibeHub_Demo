import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import "./Aboutpage.css";
import aboutusimage from "../../assets/aboutus_image.jpg";
import Cardstyle from "../../components/Card/card";
import webintro from "../../assets/website_into.jpg";
import right1 from "../../assets/right_1.jpg";
import right2 from "../../assets/right_2.jpg";
import right3 from "../../assets/right_3.jpg";

const dataforleftside = [
  {
    image: webintro,
    title: "VirtualVibeHub",
    des: "VirtualVibeHub is a online event platform which bridge the gap between physical event and virtual event by providing the same experience as physical event in online.",
  },
];
const dataforrightside = [
  {
    image: right1,
    title: "Create the virtual event",
    des: "We provide you the functionality to create the virtual event with your event manager role just by contact with our team.",
  },
  {
    image: right2,
    title: "Enjoy the virtual experience",
    des: "With virtualvibehub you can experience the hybrid event by joining them from online as well as from offline/in-person.",
  },
  {
    image: right3,
    title: "Increase your networking",
    des: "With virtualvibehub increase your networking by communicate with your peers from the comfort of your home.",
  },
];
function About() {
  return (
    <div>
      <Navbar />
      <div style={{ display: "flex", justifyContent: "center" }}>
        <img src={aboutusimage} alt="" className="imageabout" />
      </div>
      <div
        className="container"
        style={{
          marginTop: "15px",
          borderBottom: "2px solid black",
          display: "flex",
          justifyContent: "center",
        }}
      >
        <h1>About Us</h1> <br />
      </div>
      <div className="container">
        <div
          className="row"
          style={{ marginBottom: "15px", borderTop: "2px solid black" }}
        >
          <div className="col-3" style={{ marginTop: "15px" }}>
            <h3 style={{ marginBottom: "20px" }}>What is virtual Vibehub</h3>
            <Cardstyle
              image={dataforleftside[0].image}
              title={dataforleftside[0].title}
              des={dataforleftside[0].des}
            />
          </div>
          <div className="col-9" style={{ marginTop: "15px" }}>
            <h3>
              what are the benefits of virtual Vibehub? and why should you our
              virtual event platform?
            </h3>
            <div
              style={{
                marginTop: "20px",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              {dataforrightside.map((data) => {
                return (
                  <Cardstyle
                    image={data.image}
                    title={data.title}
                    des={data.des}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default About;
