import React from "react";
import Drawer from "../../../utils/Dashboard_drawer/Drawer";
import Eventadminsidebar from "../Eventadmin_sidebar/Eventadminsidebar";
import calpic from "../../../assets/EventAdminCal.png";
import circle from "../../../assets/Circle.png";
import dollar from "../../../assets/dollar.png";
import calender from "../../../assets/calender.jpg";
import graph from "../../../assets/graph.png";

function Dashboard() {
  return (
    <div className="row" style={{ width: "100vw" }}>
      <div className="col-2">
        <div className="col-2" style={{ position: "fixed" }}>
          <Eventadminsidebar dashboard="active" />
        </div>
      </div>
      <div className="col-10">
        <div className="dash-col-10">
          <Drawer />
          <div className="container">
            <div className="row mt-4">
              <h3>Dashboard</h3>
            </div>
            <div className="row">
              <div className="col-5">
                <h5>My event</h5>
                <div
                  style={{
                    width: "100%",
                    height: "270px",
                    backgroundColor: "hsl(192,24%,96%)",
                    borderRadius: "4px",
                  }}
                >
                  <div className="row">
                    <div className="col-6">
                      <h5>Total Events</h5>
                      <img
                        src={calpic}
                        alt=""
                        style={{ width: "40px", marginBottom: "15px" }}
                      ></img>
                      <span style={{ fontSize: "30px" }}>120</span>
                    </div>
                    <div
                      className="col-6"
                      style={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "end",
                        marginBottom: "15px",
                        paddingRight: "45px",
                      }}
                    >
                      <select
                        class="form-select"
                        // aria-label="Default select example"
                      >
                        <option selected>
                          <h5>This Week</h5>
                        </option>
                        <option value="1">This year</option>
                        <option value="2">This month</option>
                        <option value="3">Today</option>
                      </select>
                    </div>
                  </div>
                  <div
                    className="row"
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <img src={circle} alt="" style={{ width: "150px" }} />
                    <img src={circle} alt="" style={{ width: "150px" }} />
                    <img src={circle} alt="" style={{ width: "150px" }} />
                  </div>
                </div>
              </div>
              <div className="col-4">
                <h5>Payments</h5>
                <div
                  style={{
                    width: "100%",
                    height: "270px",
                    backgroundColor: "hsl(192,24%,96%)",
                    borderRadius: "4px",
                  }}
                >
                  <div className="row">
                    <div className="col-6">
                      {" "}
                      <h5>Total Payments</h5>
                      <img
                        src={dollar}
                        alt=""
                        style={{ width: "40px", marginBottom: "15px" }}
                      />{" "}
                      <span style={{ fontSize: "30px" }}>500</span>
                    </div>
                    <div
                      className="col-6"
                      style={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "end",
                        marginBottom: "15px",
                        paddingRight: "45px",
                      }}
                    >
                      <h5>This Week</h5>
                    </div>
                    <div
                      className="row"
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        paddingLeft: "40px",
                        paddingRight: "40px",
                      }}
                    >
                      {" "}
                      <img src={circle} alt="" style={{ width: "150px" }} />
                      <img src={circle} alt="" style={{ width: "150px" }} />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-3">
                <h5>Timeline</h5>
                <div
                  style={{
                    width: "100%",
                    height: "270px",
                    backgroundColor: "hsl(192,24%,96%)",
                    borderRadius: "4px",
                  }}
                >
                  <div className="row m-0">
                    <h5>Today</h5>
                  </div>
                  <div className="row m-0">
                    <span>
                      Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                      Aut, magnam.
                    </span>
                    <span>
                      Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                      Aut, magnam.
                    </span>
                    <span>
                      Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                      Aut, magnam.
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="row mt-4">
              <div className="col-6">
                <h5>Event Statatics</h5>
                <div
                  style={{
                    width: "100%",
                    height: "350px",
                    // backgroundColor: "hsl(192,24%,96%)",
                    borderRadius: "4px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    boxShadow: " 0 5px 20px 0 hsla(219,56%,21%,0.1)",
                  }}
                >
                  <img src={graph} alt="" style={{ width: "500px" }} />
                </div>
              </div>
              <div className="col-6">
                <h5>Calender</h5>
                <div
                  style={{
                    width: "100%",
                    height: "350px",
                    borderRadius: "4px",
                    boxShadow: " 0 5px 20px 0 hsla(219,56%,21%,0.1)",
                    display: "flex",
                    justifyContent: "center",
                    marginTop: "10px",
                  }}
                >
                  <img src={calender} alt="" style={{ width: "auto" }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
