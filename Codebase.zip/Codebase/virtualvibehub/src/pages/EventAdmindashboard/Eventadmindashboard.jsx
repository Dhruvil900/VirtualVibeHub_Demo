import React from 'react'
import Dashboard from './Eventadmindashboard/Dashboard'

function Eventadmindashboard() {
  return (
    <div>
      <Dashboard/>
    </div>
  )
}

export default Eventadmindashboard
