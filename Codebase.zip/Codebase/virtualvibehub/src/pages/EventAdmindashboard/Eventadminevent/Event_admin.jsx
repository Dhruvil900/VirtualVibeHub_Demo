import React from 'react'
import Eventadminsidebar from '../Eventadmin_sidebar/Eventadminsidebar'

function Eventadmin() {
  return (
<div className="row " style={{ width: "100vw" }}>
      <div className="col-2 ">
        <div className="col-2" style={{ position: "fixed" }}>
          <Eventadminsidebar event="active" />
        </div>
      </div>
    </div>  )
}

export default Eventadmin