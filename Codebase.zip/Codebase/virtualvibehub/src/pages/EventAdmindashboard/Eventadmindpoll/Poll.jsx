import React from 'react'
import Eventadminsidebar from '../Eventadmin_sidebar/Eventadminsidebar'

function Poll() {
  return (
<div className="row " style={{ width: "100vw" }}>
      <div className="col-2 ">
        <div className="col-2" style={{ position: "fixed" }}>
          <Eventadminsidebar poll="active" />
        </div>
      </div>
    </div>  )
}

export default Poll