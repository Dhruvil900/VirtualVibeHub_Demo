import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
// import "./Sidebar.css";
import exit_white from "../../../assets/exit_white.png";
import exit_blue from "../../../assets/exit_blue.png";
import userlogo from "../../../assets/user.png";
function Eventadminsidebar({
  dashboard,
  event,
  poll,
  people,
  createevent,
  manageevent,
  manageuser,
}) {
  const [signout, setSignout] = useState(exit_white);
  const [username, Setusername] = useState("Bhanderi Dhruvil");
  const [role, Setrole] = useState(localStorage.getItem("userrole"));

  return (
    <div className="dash-col-2" style={{ height: "99vh" }}>
      <div className="userprofile">
        <div className="row">
          <div className="col-4 usercol" style={{ paddingRight: "0px" }}>
            <img src={userlogo} alt="" style={{ width: "55px" }} />
          </div>
          <div
            className="col-8 usercol"
            style={{
              justifyContent: "center",
              alignItems: "center",
              paddingLeft: "0px",
            }}
          >
            <div className="row">
              <div
                className="col-12"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  paddingRight: "10px",
                }}
              >
                {username}
              </div>
              <div
                className="col-12 roletext"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  paddingRight: "10px",
                }}
              >
                {role}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="col" style={{ marginLeft: "20px", marginTop: "20px" }}>
        <br />
        <div>
          <NavLink to={"/admin-dashboard"} className="side-link">
            <button
              className={`btn ${dashboard}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Dashboard
            </button>{" "}
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/eventadmin-event" className="side-link">
            <button
              className={`btn ${event}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Events
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/eventadmin-people" className="side-link">
            <button
              className={`btn ${people}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              People{" "}
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/eventadmin-poll" className="side-link">
            <button
              className={`btn ${poll}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Poll
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/eventadmin-createevent" className="side-link">
            <button
              className={`btn ${createevent}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Event Creation
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          <NavLink to="/eventadmin-manageevent" className="side-link">
            <button
              className={`btn ${manageevent}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Event Management
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          <NavLink to="/eventadmin-manageuser" className="side-link">
            <button
              className={`btn ${manageuser}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
User Management            </button>
          </NavLink>
        </div>
        <br />
        <div></div>
      </div>
      <div className="signoutbutton">
        <Link to="/" className="textout">
          <button
            className="button"
            onClick={() => localStorage.removeItem("signinemail")}
            onMouseEnter={() => {
              setSignout(exit_blue);
            }}
            onMouseLeave={() => {
              setSignout(exit_white);
            }}
          >
            <img src={signout} alt="" style={{ width: "20px" }} />
            Signout
          </button>
        </Link>
      </div>
    </div>
  );
}

export default Eventadminsidebar;
