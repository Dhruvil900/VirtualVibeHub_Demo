import { addDoc, collection } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import DateRange from "../../../components/DateRange/daterange";
import TimeRange from "../../../components/Timerange/Timerange";
import { db, storage } from "../../../firebase";
import Drawer from "../../../utils/Dashboard_drawer/Drawer";
import * as Components from "../../../components/auth/Components";
import Eventadminsidebar from "../Eventadmin_sidebar/Eventadminsidebar";
import "./Createevent.css";
import dayjs from "dayjs";
import { DemoContainer, DemoItem } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { SingleInputTimeRangeField } from "@mui/x-date-pickers-pro/SingleInputTimeRangeField";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { TextField } from "@mui/material";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { v4 } from "uuid";
import { Spinner } from "react-bootstrap";
const date = new Date();
console.log(date);
const year = date.getFullYear();
const month = date.getMonth() + 1;
const day = date.getDate();
console.log(month);
const date1 = [month, day, year].join("/");
console.log(date1);
function Createevent() {
  const [time, setTime] = React.useState(() => [
    dayjs("2022-04-17T00:00"),
    dayjs("2022-04-17T00:00"),
  ]);
  let MainImgLink;
  const [loading, setLoading] = useState(true);
  const [spinner, setSpinner] = useState(false);
  const [spinners, setSpinners] = useState(false);
  const [Sspinners, setSspinners] = useState(false);
  const [Spspinners, setSpspinners] = useState(false);
  const [upimg, setUpimg] = useState(false);
  const [supimg, setsupimg] = useState(false);
  const [spupimg, setspupimg] = useState(false);
  const [upimgs, setUpimgs] = useState(false);
  const [err, setErr] = useState([]);
  const [errs, setErrs] = useState([]);
  const [file, setFile] = useState([]);
  const [files, setFiles] = useState([]);
  const [sfiles, setSFiles] = useState([]);
  const [spfiles, setSpFiles] = useState([]);
  const [Creating, setCreating] = useState(false);
  const [selectedValue, setSelectedValue] = useState("");
  const EventType = selectedValue;
  const [eventdata, setEventdata] = useState({
    EventName: "",
    EventDescriptionShort: "",
    EventDescriptionDetail: "",
    SpeakerName: "",
    Venue: "",
    EventType: "",
    Contact: "",
    Fee: "",
    StartTime: "",
    MainImage: "",
    SponsersImage: [],
    AdditionalImages: [],
    EndTime: "",
    Sponsers: "",
    SpeakerImage: [],
    Category: "",
    Date: "",
    Participants: "",
    Message: "",
    Linkdin: "",
    Instagram: "",
    Facebook: "",
    Twitter: "",
  });
  const add = async (event) => {
    setCreating(true);
    let dataerr = [];
    event.preventDefault();
    if (
      eventdata.EventName === "" ||
      eventdata.Contact === "" ||
      eventdata.Date === "" ||
      eventdata.EndTime === "" ||
      eventdata.EventDescriptionDetail === "" ||
      eventdata.EventDescriptionShort === "" ||
      eventdata.EventType === "" ||
      eventdata.Fee === "" ||
      eventdata.Venue === "" ||
      eventdata.SpeakerName === "" ||
      eventdata.Sponsers === "" ||
      eventdata.StartTime === "" ||
      eventdata.Category === "" ||
      eventdata.Participants === ""
    ) {
      dataerr.push("dataerr");
      setErr(dataerr);
      setCreating(false);
    } else {
      const adddata = await addDoc(collection(db, "events"), eventdata);
      if (adddata) {
        alert("data added");
      } else {
        console.log("data not added");
      }
      window.location.reload();
      setCreating(false);
    }
  };
  const handleInputChange = (e) => {
    var { name, value } = e.target;
    console.log(e.target.name, e.target.value);
    setEventdata({ ...eventdata, [name]: value });
    console.log(eventdata);
    console.log(EventType);
    console.log(selectedValue);
  };
  const [Category, setCategory] = useState("");

  const handleCategoryChange = (event) => {
    let category = event.target.value;
    setCategory(event.target.value);

    // console.log("Selected Option:", category,event.target.value);
    setEventdata({ ...eventdata, Category: category });
  };

  const handleothercategory = (event) => {
    let other = event.target.value;

    // console.log("Selected Option:", category,event.target.value);
    setEventdata({ ...eventdata, Category: other });
  };

  const [selectedDate, setSelectedDate] = useState(null);

  // Function to handle date change
  const handleDateChange = (newDate) => {
    // Update the state with the new date

    // Extract and use the new date
    console.log("Selected Date:", newDate);
    const date = newDate.$d.getDate(); // Day of the month (1-31)
    const month = newDate.$d.getMonth() + 1; // Month (0-11), so we add 1 to make it (1-12)
    const year = newDate.$d.getFullYear();
    console.log(month);
    const date1 = [date, month, year].join("/");
    console.log(date1);
    setSelectedDate(date1);

    setEventdata({ ...eventdata, Date: date1 });

    // Perform any other actions with the new date as needed
  };

  const handleTimeChange = (times) => {
    setTime(times);
    const startTime = times[0].format("h:mm A");
    const endTime = times[1].format("h:mm A");
    console.log(startTime);
    console.log(endTime);
    setEventdata({ ...eventdata, StartTime: startTime, EndTime: endTime });
  };
  // Function to handle select change
  const handleSelectChange = (e) => {
    // Get the value of the selected option
    const selectedOption = e.target.value;

    // Update the state with the selected value
    setSelectedValue(selectedOption);

    // Do something with the selected value
    console.log("Selected Option:", selectedOption);
    setEventdata({ ...eventdata, EventType: selectedOption });

    // You can perform any other actions with the selected value here
  };
  const uploadimgs = async (e) => {
    let errors = [];
    let img = [];
    e.preventDefault();
    if (files.length === 0) {
      errors.push("err");
      setErrs(errors);
    } else {
      setSpinners(true);
      setErrs(errors);
      console.log(files);

      for await (const file of files) {
        console.log(file);
        const imgs = ref(storage, `images/${v4()}`);

        // Uploading the selected image file to Firebase storage
        uploadBytes(imgs, file).then((Images) => {
          console.log(Images, "imgs");

          // Retrieving the download URL for the uploaded image
          getDownloadURL(Images.ref).then((val) => {
            console.log(val);
            img.push(val);
            console.log(img);
            setEventdata({ ...eventdata, AdditionalImages: img });
            setTimeout(() => {
              setSpinners(false);
              setUpimgs(true);
            }, 2000);
          });
        });
      }
      console.log(img);
      console.log("finish");
    }
  };
  const supload = async (e) => {
    let errors = [];
    let img = [];
    e.preventDefault();
    if (sfiles.length === 0) {
      errors.push("sponsererr");
      setErrs(errors);
    } else {
      setSspinners(true);
      setErrs(errors);
      console.log(sfiles);

      for await (const file of sfiles) {
        console.log(file);
        const imgs = ref(storage, `images/${v4()}`);

        // Uploading the selected image file to Firebase storage
        uploadBytes(imgs, file).then((Images) => {
          console.log(Images, "imgs");

          // Retrieving the download URL for the uploaded image
          getDownloadURL(Images.ref).then((val) => {
            console.log(val);
            img.push(val);
            console.log(img);
            setEventdata({ ...eventdata, SponsersImage: img });
            setTimeout(() => {
              setSspinners(false);
              setsupimg(true);
            }, 2000);
          });
        });
      }
      console.log(img);
      console.log("finish");
    }
  };
  const spupload = async (e) => {
    let errors = [];
    let img = [];
    e.preventDefault();
    if (spfiles.length === 0) {
      errors.push("speakererr");
      setErrs(errors);
    } else {
      setSpspinners(true);
      setErrs(errors);
      console.log(spfiles);

      for await (const file of spfiles) {
        console.log(file);
        const imgs = ref(storage, `images/${v4()}`);

        // Uploading the selected image file to Firebase storage
        uploadBytes(imgs, file).then((Images) => {
          console.log(Images, "imgs");

          // Retrieving the download URL for the uploaded image
          getDownloadURL(Images.ref).then((val) => {
            console.log(val);
            img.push(val);
            console.log(img);
            setEventdata({ ...eventdata, SpeakerImage: img });
            setTimeout(() => {
              setSpspinners(false);
              setspupimg(true);
            }, 2000);
          });
        });
      }
      console.log(img);
      console.log("finish");
    }
  };
  const uploadimg = (e) => {
    let error = [];
    e.preventDefault();
    console.log(file);
    if (file.length === 0) {
      error.push("err");
      console.log(error);
      setErr(error);
    } else {
      setSpinner(true);
      setErr(error);
      console.log(file);
      for (let i=0;i<1;i++) {
        console.log(file);
        const imgs = ref(storage, `images/${v4()}`);

        uploadBytes(imgs, file).then((xyz) => {
          console.log(xyz, "imgs");

          getDownloadURL(xyz.ref).then((val) => {
            console.log(val);
            MainImgLink = val;
            console.log(MainImgLink);
            setEventdata({ ...eventdata, MainImage: MainImgLink });
            setTimeout(() => {
              setSpinner(false);
              setUpimg(true);
            }, 2000);
          });
        });
      }
      console.log(MainImgLink);
      console.log("finish");
    }
  };
  return (
    <div className="row " style={{ width: "100vw" }}>
      <div className="col-2 ">
        <div className="col-2" style={{ position: "fixed" }}>
          <Eventadminsidebar createevent="active" />
        </div>
      </div>
      <div className="col-10">
        <div className=" dash-col-10">
          <Drawer />
          <div className="container" style={{ height: "90vh" }}>
            <div className="row mt-4 ">
              <div className="m-0">
                <div style={{ fontSize: "20px", fontWeight: "bold italic" }}>
                  Create a new event here. Fill in all the required fields
                  input.
                </div>
              </div>
            </div>
            <div className="m-0 mt-3">
              <form action="">
                <input
                  type="text"
                  className="form-control"
                  style={{ width: "60vw" }}
                  name="EventName"
                  onChange={handleInputChange}
                  placeholder="Event Name"
                  id=""
                />
                <input
                  type="text"
                  className="form-control mt-2"
                  onChange={handleInputChange}
                  name="EventDescriptionShort"
                  placeholder="Event Description in short (in one to two line)"
                  id=""
                />
                <div class="mb-3">
                  <textarea
                    className="form-control mt-2"
                    id=""
                    onChange={handleInputChange}
                    name="EventDescriptionDetail"
                    placeholder="Event Description long"
                    rows="3"
                  ></textarea>
                </div>
                <input
                  type="text"
                  className="form-control mt-2"
                  placeholder="Speaker Name (s) if any"
                  name="SpeakerName"
                  onChange={handleInputChange}
                  id=""
                />
                <div className="row">
                  <div className="mt-2 col-4">
                    <h6 className="mb-1" style={{ marginLeft: "5px" }}>
                      Select the type of the event
                    </h6>
                    <select
                      className="form-select"
                      onChange={handleSelectChange}
                      value={selectedValue} // Set the value of the select to the selectedValue state
                    >
                      <option value="">Select type of Event</option>
                      <option value="Conference">Conference</option>
                      <option value="Webinar">Webinar</option>
                      <option value="Meeting">Meeting</option>
                      <option value="Workshop">Workshop</option>
                    </select>
                  </div>
                  <div className="col-8 mt-2">
                    <h6 className="mb-1" style={{ marginLeft: "5px" }}>
                      Select the Category of the event
                    </h6>{" "}
                    <div className="row">
                      <div className="col-6">
                        <select
                          className="form-select"
                          id="category"
                          value={Category}
                          onChange={handleCategoryChange}
                        >
                          <option value="">Select a category</option>
                          <option value="Programming">Programming</option>
                          <option value="Music">Music</option>
                          <option value="Sport">Sport</option>
                          <option value="Trading">Trading</option>
                          <option value="Design">Design</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div className="col-6">
                        {Category === "Other" && (
                          <div>
                            <label htmlFor="otherCategory">Specify:</label>
                            <input
                              className=" w-auto"
                              type="text"
                              onChange={handleothercategory}
                              id="otherCategory"
                              style={{
                                borderBottom: "2px solid black",
                              }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row m-0">
                  <textarea
                    className="form-control mt-2"
                    style={{ width: "35vw" }}
                    name="Venue"
                    placeholder="Venue"
                    onChange={handleInputChange}
                    id=""
                  />
                  <div style={{ width: "18vw" }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DemoContainer
                        components={["DateRangePicker", "DateRangePicker"]}
                      >
                        <DemoItem label="" component="DateRangePicker">
                          <DatePicker onChange={handleDateChange} />
                        </DemoItem>
                      </DemoContainer>
                    </LocalizationProvider>
                  </div>
                  <div style={{ width: "25vw" }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DemoContainer components={["SingleInputTimeRangeField"]}>
                        <SingleInputTimeRangeField
                          label="Start and End time of event"
                          value={time}
                          onChange={handleTimeChange}
                        />
                      </DemoContainer>

                      {/* Displaying the extracted start and end times in 12-hour AM/PM format */}
                    </LocalizationProvider>{" "}
                  </div>
                </div>
                <div className="row m-0">
                  <input
                    type="text"
                    style={{ width: "45vw" }}
                    className="form-control mt-2"
                    onChange={handleInputChange}
                    placeholder="Contact of the organizer for any query"
                    name="Contact"
                    id=""
                  />
                  <div style={{ width: "15vw" }}>
                    <input
                      type="text"
                      className="form-control mt-2"
                      onChange={handleInputChange}
                      placeholder="Registration Fee"
                      name="Fee"
                      id=""
                    />
                  </div>
                  <div style={{ width: "18vw" }}>
                    <input
                      type="text"
                      className="form-control mt-2"
                      onChange={handleInputChange}
                      placeholder="Total No. of participants"
                      name="Participants"
                      id=""
                    />
                  </div>
                </div>
                <input
                  className="form-control mt-2"
                  name="Sponsers"
                  onChange={handleInputChange}
                  placeholder="Sponsers"
                  id=""
                />
                <div className="mt-2">
                  <h6 className="mb-1" style={{ marginLeft: "5px" }}>
                    Links of social media (if any)
                  </h6>
                  <input
                    className="form-control mt-2"
                    name="Message"
                    onChange={handleInputChange}
                    placeholder="Any messages for sharing post related to event (ex.: share post using #xyz) "
                    id=""
                  />
                  <input
                    className="form-control mt-2"
                    name="Linkdin"
                    onChange={handleInputChange}
                    placeholder="Link of Linkdin (Optional)"
                    id=""
                  />
                  <input
                    className="form-control mt-2"
                    name="Instagram"
                    onChange={handleInputChange}
                    placeholder="Link of Instagram (Optional)"
                    id=""
                  />
                  <input
                    className="form-control mt-2"
                    name="Twitter"
                    onChange={handleInputChange}
                    placeholder="Link of Twitter (Optional)"
                    id=""
                  />
                  <input
                    className="form-control mt-2"
                    name="Facebook"
                    onChange={handleInputChange}
                    placeholder="Link of Facebook (Optional)"
                    id=""
                  />
                </div>
                <div>
                  <h6
                    className="mb-1"
                    style={{ marginLeft: "5px", marginTop: "10px" }}
                  >
                    Images for event
                  </h6>
                  <div
                    style={{ border: "2px solid black", borderRadius: "7px" }}
                  >
                    <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                      Main image of your event which will shown to users on home
                      and events page
                    </h6>
                    <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                      Add Image (One image):
                    </h6>
                    <input
                      type="file"
                      onChange={(e) => setFile(e.target.files[0])}
                    />
                    <Components.Button
                      type="submit"
                      onClick={uploadimg}
                      disabled={spinner || spinners || Sspinners || Spspinners}
                      style={{ marginBottom: "10px" }}
                    >
                      {spinner && (
                        <Spinner
                          size="sm"
                          style={{
                            marginRight: "5px",
                          }}
                        ></Spinner>
                      )}{" "}
                      {spinner ? "Uploading..." : "Upload Image"}
                    </Components.Button>{" "}
                    {err.includes("err") && (
                      <p style={{ color: "red" }}>Image is Required!</p>
                    )}
                  </div>
                  <div
                    className="mt-3"
                    style={{ border: "2px solid black", borderRadius: "7px" }}
                  >
                    <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                      Additional images that will display on details page for
                      event
                    </h6>
                    <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                      Add Image (s):
                    </h6>
                    <input
                      type="file"
                      onChange={(e) => setFiles(e.target.files)}
                      multiple
                    />
                    <Components.Button
                      type="submit"
                      onClick={uploadimgs}
                      disabled={spinner || spinners || Sspinners || Spspinners}
                      style={{ marginBottom: "10px" }}
                    >
                      {spinners && (
                        <Spinner
                          size="sm"
                          style={{
                            marginRight: "5px",
                          }}
                        ></Spinner>
                      )}{" "}
                      {spinners ? "Uploading..." : "Upload Images"}
                    </Components.Button>{" "}
                    {errs.includes("err") && (
                      <p style={{ color: "red" }}>
                        Atleast One Image is required!
                      </p>
                    )}
                  </div>
                  <div
                    className="mt-3"
                    style={{ border: "2px solid black", borderRadius: "7px" }}
                  >
                    <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                      Sponsers Images which will display on sponsers gallery
                    </h6>
                    <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                      Add Image (s):
                    </h6>
                    <input
                      type="file"
                      onChange={(e) => setSFiles(e.target.files)}
                      multiple
                    />
                    <Components.Button
                      type="submit"
                      onClick={supload}
                      disabled={spinner || spinners || Sspinners || Spspinners}
                      style={{ marginBottom: "10px" }}
                    >
                      {Sspinners && (
                        <Spinner
                          size="sm"
                          style={{
                            marginRight: "5px",
                          }}
                        ></Spinner>
                      )}
                      {Sspinners ? "Uploading..." : "Upload Images"}
                    </Components.Button>{" "}
                    {errs.includes("sponsererr") && (
                      <p style={{ color: "red" }}>
                        Atleast One Image is required!
                      </p>
                    )}
                  </div>
                </div>
                <div
                  className="mt-3"
                  style={{ border: "2px solid black", borderRadius: "7px" }}
                >
                  <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                    Speaker (s) Images
                  </h6>
                  <h6 className="mt-3" style={{ marginLeft: "5px" }}>
                    Add Image (s):
                  </h6>
                  <input
                    type="file"
                    onChange={(e) => setSpFiles(e.target.files)}
                    multiple
                  />
                  <Components.Button
                    type="submit"
                    onClick={spupload}
                    disabled={spinner || spinners || Sspinners || Spspinners}
                    style={{ marginBottom: "10px" }}
                  >
                    {Spspinners && (
                      <Spinner
                        size="sm"
                        style={{
                          marginRight: "5px",
                        }}
                      ></Spinner>
                    )}
                    {Spspinners ? "Uploading..." : "Upload Images"}
                  </Components.Button>{" "}
                  {errs.includes("speakererr") && (
                    <p style={{ color: "red" }}>
                      Atleast One Image is required!
                    </p>
                  )}
                </div>
                <div className="row">
                  <div className="w-auto pr-0">
                    <button
                      type="submit"
                      className="btn mt-2"
                      style={{ width: "auto", marginBottom: "15px" }}
                      onClick={add}
                      disabled={upimg && upimgs && supimg && spupimg ? false : true}
                    >
                      {Creating && (
                        <Spinner
                          size="sm"
                          style={{
                            marginRight: "5px",
                          }}
                        ></Spinner>
                      )}{" "}
                      Create Event
                    </button>
                  </div>
                  <div
                    className="w-auto p-0"
                    style={{
                      marginLeft: "10px",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    {err.includes("dataerr") && (
                      <h6 style={{ color: "red" }}>
                        Please fill all the required fiels!
                      </h6>
                    )}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Createevent;
