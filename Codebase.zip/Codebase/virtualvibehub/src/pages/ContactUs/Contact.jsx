import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./contact.css";
import pic1 from "../../assets/1.png";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
export default function ContactUs() {
  return (
    <div>
      <Navbar />
      <div className="maincontact">
        <div className="container-fluid">
          <Row className="mb-5 mt-3">
            <Col lg="8">
              <h1 className="display-4 mb-4 text-black">Contact Me</h1>
              <hr className="t_border my-4 ml-0 text-left" style={{color:"black",width:"100%", border:" 2px solid black"}} />
            </Col>
          </Row>
          <Row className="sec_sp">
            <Col lg="5" className="mb-5">
              <img
                src={pic1}
                alt=""
                style={{ heignt: "500px", width: "500px" }}
              />
            </Col>
            <Col lg="7" className="d-flex align-items-center">
              <form className="contact__form w-100">
                <Row>
                  <Col lg="6" className="form-group">
                    <input
                      className="form-control"
                      id="name"
                      name="name"
                      placeholder="Name"
                      type="text"
                      color="white"
                      required
                    />
                  </Col>
                  <Col lg="6" className="form-group">
                    <input
                      className="form-control rounded-0"
                      id="email"
                      name="email"
                      placeholder="Email"
                      type="email"
                      required
                    />
                  </Col>
                </Row>
                <textarea
                  className="form-control rounded-0"
                  id="message"
                  name="message"
                  placeholder="Message"
                  rows="5"
                  required
                ></textarea>
                <br />
                <Row>
                  <Col lg="12" className="form-group">
                    <button
                      className="btn"
                      type="submit"
                    >
                      Send
                    </button>
                    <br />
                    <br />
                    <br />
                  </Col>
                </Row>
              </form>
            </Col>
          </Row>
        </div>
        <Footer />
      </div>
    </div>
  );
}
