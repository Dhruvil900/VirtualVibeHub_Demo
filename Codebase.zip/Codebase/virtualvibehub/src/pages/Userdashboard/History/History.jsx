import React from "react";
import Drawer from "../../../utils/Dashboard_drawer/Drawer";
import Sidebar from "../Sidebar/Sidebar";

function History() {
  return (
    <div className="row" style={{ width: "100vw" }}>
      <div className="col-2">
        <div className="col-2" style={{ position: "fixed" }}>
          <Sidebar history="active" />
        </div>
      </div>
      <div className="col-10">
        <div className="dash-col-10">
          <Drawer />
          <br />
          <div>
            <h2 style={{ paddingLeft: "6px" }}>History</h2>
          </div>
        </div>
      </div>
    </div>
  );
}

export default History;
