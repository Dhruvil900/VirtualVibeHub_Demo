import React, { useState } from "react";
import "../Sidebar/Sidebar.css"
import Drawer from "../../../utils/Dashboard_drawer/Drawer";
import Sidebar from "../Sidebar/Sidebar";
import EventList_all from "./EventList_all";
import EventList_user from "./EventList_user";

function Events() {
  const [toggel, setToggel] = useState(false);
  return (
    <div className="row" style={{ width: "100vw" }}>
      <div className="col-2">
        <div className="col-2" style={{ position: "fixed" }}>
          <Sidebar event="active" />
        </div>
      </div>
      <div className="col-10">
        <div className="dash-col-10">
          <Drawer />
          <br />
          <div>
            <h2 style={{ paddingLeft: "6px" }}>Upcoming Events</h2>
            <div className="container-fluid m-0 p-0">
              <div className="row">
                <div className="row">
                  <div
                    className="w-auto "
                    style={{ marginLeft: "7px" }}
                    onClick={() => setToggel(false)}
                  >
                    {" "}
                    <div className={`btn w-auto ${toggel ? "" : "myevent"}`} style={{border:"2px solid black", borderRadius:"5px",paddingRight:"5px",paddingLeft:"5px"}}>
                      My Events
                    </div>
                  </div>
                  <div className="w-auto" onClick={() => setToggel(true)}>
                    {" "}
                    <div className={`btn w-auto ${toggel ? "myevent" : ""}`} style={{border:"2px solid black", borderRadius:"5px",paddingRight:"5px",paddingLeft:"5px"}}>All Events</div>
                  </div>
                </div>
                <div className="m-0 p-0 mt-3">
                  <div hidden={toggel}>
                    <EventList_user />
                  </div>
                  <div hidden={!toggel}>
                    <EventList_all />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div></div>
    </div>
  );
}

export default Events;
