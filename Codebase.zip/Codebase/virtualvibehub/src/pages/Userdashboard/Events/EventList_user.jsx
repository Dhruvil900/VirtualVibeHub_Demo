import React from "react";
import red from "../../../assets/red-cr.png";
import yellow from "../../../assets/yellow-cr.png";
import green from "../../../assets/green-cr.png";
import blue from "../../../assets/blue-cr.png";
function EventList_user() {
  return (
    <div
      className="m-0 p-0"
      style={{
        overflow: "auto",
        height: "81.2vh",
        display: "flex",
        justifyContent: "center",
      }}
    >
      <div
        className="row m-0 p-0 mt-2"
        style={{
          height: "20vh",
          width: "79vw",
          boxShadow: "0 5px 20px 0 hsla(219,56%,21%,0.1)",
          borderRadius: "20px",
        }}
      >
        <div className="col-2">
          3
        </div>
        <div className="col-8   " >
          <div className="row mb-2 mt-1" style={{ opacity: 0.5 }}>
            22nd April 2024 | 10:00AM to 12:00PM
          </div>
          <div className="row" style={{ fontWeight: "600", fontSize: "20px" }}>
            Cloud computing solution Architect for getting deep knowledge of
            cloud computing
          </div>
          <div
            className="row mt-2"
            style={{ display: "flex", alignItems: "center" }}
          >
            <img
              className="m-0 p-0"
              src={blue}
              style={{ width: "15px", height: "15px" }}
            />
            Webinar | Programming
          </div>
          <div className="row mt-2 mb-1">100 | Virtual Event</div>
        </div>
        <div className="col-2" ></div>
      </div>
    </div>
  );
}

export default EventList_user;
