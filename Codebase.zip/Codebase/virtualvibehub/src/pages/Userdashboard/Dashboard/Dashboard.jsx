import React, { useEffect, useState } from "react";

import logo from "../../../assets/bird.png";
import calender from "../../../assets/calender.png";
import Search from "../../../components/Search/search";
import Upcomingevent from "../../../components/Upcoming_Event/Upcomingevent";
import Stats from "../../../components/Stats/Stats";
import { Link } from "react-router-dom";
import Sidebar from "../Sidebar/Sidebar";
import Drawer from "../../../utils/Dashboard_drawer/Drawer";
function Dashboard() {
  
  return (
    <div className="row" style={{ width: "100vw" }}>

      <div className="col-2">
      <div className="col-2" style={{ position: "fixed" }}>

        <Sidebar dashboard="active" />
      </div>
      </div>
      <div className="col-10">
        <div className="dash-col-10">
          <Drawer/>
          <br />
          <h2>Dashboard</h2>
          <div className="container-fluid">
            <div className="row">
              <div className="col-7">
                My Upcoming Events
                <div className="upcomingeventdiv">
                  <div
                    style={{
                      marginLeft: "30px",
                      marginRight: "30px",
                      paddingTop: "40px",
                      overflow: "hidden",
                    }}
                  >
                    <Upcomingevent />
                  </div>
                </div>
              </div>
              <div className="col-5">
                Statatics of Events
                <div
                  className="upcomingeventdiv"
                  style={{ backgroundColor: "white" }}
                >
                  <Stats />
                </div>
              </div>
            </div>
          </div>
        </div>{" "}
      </div>
    </div>
  );
}

export default Dashboard;
