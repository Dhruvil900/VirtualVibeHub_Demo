import { doc, getDoc, updateDoc } from "firebase/firestore";
import React, { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import IdContext from "../../../Context/usercontext";
import { db } from "../../../firebase";
function EventList_live({ date, time, title, id, started, image }) {
  const [fetchdata, setFetchdata] = useState([]);
  let status;
  const fetch = async () => {
    const snapshot = await getDoc(doc(db, "events", id));
    const fetchdata = {
      ...snapshot.data(),
    };
    setFetchdata(fetchdata);
    console.log(fetchdata.status);
    status = fetchdata.status;
  };
  const statusupdate = async () => {
    const documentRef = doc(db, "events", id);
    await updateDoc(documentRef, { status: "completed" });
  };
  let navigate = useNavigate();
  const redirect = () => {
    if (localStorage.getItem("userrole") === "Speaker") {
      navigate(`/livestreaming/${id}`);
    } else {
      fetch().then(() => {
        if (status==="Active") {
          window.location.href = `/livestreaming/${id}`;
        } else {
          alert("meeting has not been started yet");
        }
      });
    }
  };
  window.addEventListener("beforeunload", function (event) {
    statusupdate()
    // Remove the livestreaming data from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      let key = localStorage.key(i);
      if (key.startsWith("z_")) {
        // Remove the data with keys starting with "z_"
        localStorage.removeItem(key);
      }
    }
  });
  window.addEventListener("popstate", function (event) {
    statusupdate()
    // Remove the livestreaming data from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      let key = localStorage.key(i);
      if (key.startsWith("z_")) {
        // Remove the data with keys starting with "z_"
        localStorage.removeItem(key);
      }
    }
  });
  return (
    <div
      className="m-0 mb-3 p-0"
      style={{
        display: "flex",
        align: "center",
        justifyContent: "center",
      }}
    >
      <div
        className="row m-0 p-0 mt-2"
        style={{
          height: "15vh",
          width: "79vw",
          boxShadow: "0 5px 20px 0 hsla(219,56%,21%,0.1)",
          borderRadius: "20px",
          display: "flex",
          alignItems: "center",
        }}
      >
        <div className="" style={{ width: "12.66666667%" }}>
          <img src={image} alt="" style={{ width: "100px" }} />
        </div>
        <div style={{ width: "76.66666667%" }}>
          <div className="row mb-2 mt-1" style={{ opacity: 0.5 }}>
            {date} | {time}
          </div>
          <div className="row" style={{ fontWeight: "600", fontSize: "20px" }}>
            {title}
          </div>
        </div>
        <div style={{ width: "auto" }}>
          {started ? (
            <button className="btn w-auto" onClick={redirect}>
              Check detail
            </button>
          ) : (
            <button
              className="btn w-auto"
              style={{ marginLeft: "15px" }}
              onClick={redirect}
            >
              Join Now
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default EventList_live;
