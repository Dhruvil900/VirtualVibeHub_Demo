import { collection, getDocs } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { db } from "../../../firebase";
import Drawer from "../../../utils/Dashboard_drawer/Drawer";
import Sidebar from "../Sidebar/Sidebar";
import EventList_live from "./EventList_live";
import EventList_user from "./EventList_live";
import EventList_all from "./EventList_next";

function Live() {
  const [toggel, setToggel] = useState(false);
  const [fetchdata, setFetchdata] = useState([]);
  const [feesMoreThan100, setFeesMoreThan100] = useState([]);

  const fetch = async () => {
    const now = new Date();

    // const hours = now.getHours() % 12;

    // const minutes = now.getMinutes();
    const snapshot = await getDocs(collection(db, "events"));
    const fetchdata = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    let filterdata = [];
    fetchdata.forEach((element) => {
      // let starttime = element.StartTime;
      // console.log(starttime);
      // let a = starttime.split(" ");
      // let hour = parseInt(a[0].split(":")[0]);
      // let minute = parseInt(a[0].split(":")[1]);
      // console.log(hours);
      // if(hour+1==hours && )
      const currentTime = new Date();

      // Filter events that will occur within the next hour
      const filteredEvents = fetchdata.filter((event) => {
        // Parse event time into a Date object
        const eventTime = parseEventTime(event.StartTime);

        // Calculate the time difference in milliseconds
        const timeDifference = eventTime.getTime() - currentTime.getTime();
        console.log(currentTime);
        // Define the time interval for one hour
        const oneHour = 60 * 60 * 1000; // One hour in milliseconds
        console.log(oneHour, timeDifference);
        return timeDifference <= oneHour && timeDifference > 0;
      });
      setFeesMoreThan100(filteredEvents);

      setFetchdata(fetchdata);
      console.log(fetchdata, feesMoreThan100);
    });
  };
  const parseEventTime = (timeString) => {
    // Split the time string into hours, minutes, and period (AM/PM)
    const [time, period] = timeString.split(" ");
    const [hours, minutes] = time.split(":");
    console.log(hours, minutes);
    // Parse hours and minutes into integers
    let parsedHours = parseInt(hours);
    let parsedMinutes = parseInt(minutes);

    // Adjust hours for PM period
    if (period === "PM" && parsedHours !== 12) {
      parsedHours += 12;
    }

    // Create a new Date object with the parsed time
    const eventTime = new Date();
    eventTime.setHours(parsedHours);
    eventTime.setMinutes(parsedMinutes);
    console.log(eventTime);
    return eventTime;
  };
  useEffect(() => {
    fetch();
  }, []);
  return (
    <div className="row" style={{ width: "100vw" }}>
      <div className="col-2">
        <div className="col-2" style={{ position: "fixed" }}>
          <Sidebar live="active" />
        </div>
      </div>
      <div className="col-10">
        <div className="dash-col-10">
          <Drawer />
          <br />
          <div>
            <h2 style={{ paddingLeft: "6px" }}>Your upcoming live events</h2>
            <div className="container-fluid m-0 p-0">
              <div className="row">
                <div className="row">
                  <div
                    className="w-auto "
                    style={{ marginLeft: "7px" }}
                    onClick={() => setToggel(false)}
                  >
                    {" "}
                    <div
                      className={`btn w-auto ${toggel ? "" : "myevent"}`}
                      style={{
                        border: "2px solid black",
                        borderRadius: "5px",
                        paddingRight: "5px",
                        paddingLeft: "5px",
                      }}
                    >
                      Live event
                    </div>
                  </div>
                  <div className="w-auto" onClick={() => setToggel(true)}>
                    {" "}
                    <div
                      className={`btn w-auto ${toggel ? "myevent" : ""}`}
                      style={{
                        border: "2px solid black",
                        borderRadius: "5px",
                        paddingRight: "5px",
                        paddingLeft: "5px",
                      }}
                    >
                      Next events in 1 hour
                    </div>
                  </div>
                </div>
                <div className="m-0 p-0 mt-3">
                  <div hidden={toggel}>
                    {fetchdata.map((item) => {
                      let stime = item.StartTime;
                      let etime = item.EndTime;
                      let time = stime + " - " + etime;
                      return (
                        <EventList_live
                          image={item.MainImage}
                          title={item.EventName}
                          time={time}
                          date={item.Date}
                          id={item.id}
                        />
                      );
                    })}
                  </div>
                  {feesMoreThan100.map((item) => {
                    let stime = item.StartTime;
                    let etime = item.EndTime;
                    let time = stime + " - " + etime;
                    return (
                      <div hidden={!toggel}>
                        <EventList_live
                          image={item.MainImage}
                          title={item.EventName}
                          time={time}
                          date={item.Date}
                          id={item.id}
                          started="true"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Live;
