import { appid, secret } from "../../../zego";
import * as React from "react";
import { ZegoUIKitPrebuilt } from "@zegocloud/zego-uikit-prebuilt";
import { useLocation, useParams } from "react-router-dom";
import { useMemo } from "react";
import { useState } from "react";
import IdContext from "../../../Context/usercontext";
import { useContext } from "react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../../../firebase";

function randomID(len) {
  let result = "";
  if (result) return result;
  var chars = "12345qwertyuiopasdfgh67890jklmnbvcxzMNBVCZXASDQWERTYHGFUIOLKJP",
    maxPos = chars.length,
    i;
  len = len || 5;
  for (i = 0; i < len; i++) {
    result += chars.charAt(Math.floor(Math.random() * maxPos));
  }
  return result;
}

export function getUrlParams(url = window.location.href) {
  let urlStr = url.split("?")[1];
  return new URLSearchParams(urlStr);
}
export default function Room() {
  let { id } = useParams();
  console.log(id);
  // const reload=useMemo(() => window.location.reload(), [1])

  let Urole = localStorage.getItem("userrole");
  const location = useLocation();
  let roomID = id;
  console.log(roomID);
  const statusupdate = async (stat) => {
    const documentRef = doc(db, "events", roomID);
    await updateDoc(documentRef, { status: stat });
  };
  window.addEventListener("beforeunload", function (event) {
    statusupdate("Completed");
    // Remove the livestreaming data from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      let key = localStorage.key(i);
      if (key.startsWith("z_")) {
        // Remove the data with keys starting with "z_"
        localStorage.removeItem(key);
      }
    }
  });
  window.addEventListener("popstate", function (event) {
    statusupdate("Completed");
    // Remove the livestreaming data from localStorage
    for (let i = 0; i < localStorage.length; i++) {
      let key = localStorage.key(i);
      if (key.startsWith("z_")) {
        // Remove the data with keys starting with "z_"
        localStorage.removeItem(key);
      }
    }
  });
  let role_str = getUrlParams(window.location.href).get("role") || "Host";
  const role = ZegoUIKitPrebuilt.Host;

  let sharedLinks = [];
  if (role === ZegoUIKitPrebuilt.Host || role === ZegoUIKitPrebuilt.Cohost) {
    sharedLinks.push({
      name: "Join as co-host",
      url: `http://localhost:3000/livestreaming/${roomID}`,
    });
  }
  sharedLinks.push({
    name: "Join as audience",
    url: `http://localhost:3000/livestreaming/${id}`,
  });
  // generate Kit Token
  const appID = appid;
  const serverSecret = secret;
  const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
    appID,
    serverSecret,
    roomID,
    randomID(5),
    randomID(5)
  );

  const { setId } = useContext(IdContext);
  // start the call
  let myMeeting = async (element) => {
    // Create instance object from Kit Token.
    const zp = ZegoUIKitPrebuilt.create(kitToken);
    // start the call
    zp.joinRoom({
      container: element,
      scenario: {
        mode: ZegoUIKitPrebuilt.LiveStreaming,
        config: {
          role,
        },
      },
      sharedLinks,
    });
    statusupdate("Active");
  };
  const [isRecording, setIsRecording] = useState(false);
  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };
  return (
    <div>
      <div
        className="myCallContainer"
        ref={myMeeting}
        style={{ width: "100vw", height: "100vh" }}
      ></div>
      <button onClick={toggleRecording}>
        {isRecording ? "Stop Recording" : "Start Recording"}
      </button>
    </div>
  );
}
