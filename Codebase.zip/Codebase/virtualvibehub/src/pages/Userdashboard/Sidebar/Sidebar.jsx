import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import "./Sidebar.css";
import exit_white from "../../../assets/exit_white.png";
import exit_blue from "../../../assets/exit_blue.png";
import userlogo from "../../../assets/user.png";
function Sidebar({ dashboard, event, live, history, notification }) {
  const [signout, setSignout] = useState(exit_white);
  const [username, Setusername] = useState("Bhanderi Dhruvil");
  const role = localStorage.getItem("userrole");
  return (
    <div className="dash-col-2" style={{ height: "98.8vh" }}>
      <div className="userprofile">
        <div className="row">
          <div className="col-4 usercol" style={{ paddingRight: "0px" }}>
            <img src={userlogo} alt="" style={{ width: "55px" }} />
          </div>
          <div
            className="col-8 usercol"
            style={{
              justifyContent: "center",
              alignItems: "center",
              paddingLeft: "0px",
            }}
          >
            <div className="row">
              <div className="col-12">{username}</div>
              <div className="col-12 roletext" style={{ marginLeft: "10%" }}>
                {role}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="col" style={{ marginLeft: "20px", marginTop: "20px" }}>
        <br />
        <div>
          <NavLink to={"/user-dashboard"} className="side-link">
            <button
              className={`btn ${dashboard}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Dashboard
            </button>{" "}
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/user-event" className="side-link">
            <button
              className={`btn ${event}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Events
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/user-live" className="side-link">
            <button
              className={`btn ${live}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              Live Events
            </button>
          </NavLink>
        </div>
        <br />
        <div>
          {" "}
          <NavLink to="/user-history" className="side-link">
            <button
              className={`btn ${history}`}
              style={{
                width: "auto",
                borderRadius: "10px",
                transition: "0.6s",
              }}
            >
              History
            </button>
          </NavLink>
        </div>
        <br />
        <div> </div>
      </div>
      <div className="signoutbutton">
        <Link to="/" className="textout">
          <button
            className="button"
            onClick={() => {
              localStorage.removeItem("signinemail");
              localStorage.removeItem("useruid");
            }}
            onMouseEnter={() => {
              setSignout(exit_blue);
            }}
            onMouseLeave={() => {
              setSignout(exit_white);
            }}
          >
            <img src={signout} alt="" style={{ width: "20px" }} />
            Signout
          </button>
        </Link>
      </div>
    </div>
  );
}

export default Sidebar;
