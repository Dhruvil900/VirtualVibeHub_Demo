import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./Userdashboard.css";
import Sidebar from "./Sidebar/Sidebar";
import Dashboard from "./Dashboard/Dashboard";

function Userdashboard() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}

export default Userdashboard;
