import React, { useEffect, useState } from "react";
// Importing uuid to generate unique identifiers for image storage references
import { v4 } from "uuid";

// Importing Firebase storage and Firestore functionalities
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "../../firebase.jsx";
import { addDoc, collection, doc, getDocs, setDoc } from "firebase/firestore";
var img = [];
var imgdata = [];
function Imageadd() {
  // Initializing state variables
  const [txt, setTxt] = useState("");
  // const [img, setImg] = useState([]);
  const [data, setData] = useState([{}]);
  const [isupload, setIsupload] = useState(false);
  const [fetchdata, setFetchdata] = useState([]);
  const [files, setFiles] = useState([]);
  // Function to add new image and text data to the Firestore database
  const add = async (event) => {
    event.preventDefault();
    console.log(img);

    const adddata = await addDoc(collection(db, "newimagetext"), {
      image: img,
    }).then((val) => {
      console.log(val);
      console.log(img);
      alert("success");
    });
  };

  // Function to handle image file input change
  //   function handleChange(e) {
  // setIsupload(false)
  //     console.log(e.target.files[0]);

  //     // Generating a unique identifier for the image storage reference
  //     const imgs = ref(storage, `images/${v4()}`);

  //     // Uploading the selected image file to Firebase storage
  //     uploadBytes(imgs, e.target.files[0]).then((xyz) => {
  //       console.log(xyz, "imgs");

  //       // Retrieving the download URL for the uploaded image
  //       getDownloadURL(xyz.ref).then((val) => {
  //         console.log(val);
  //         setImg(val);
  //         setIsupload(true)
  //       });
  //     });

  //   }
  const handle = async (e) => {
    e.preventDefault();
    console.log(files);

    for await (const file of files) {
      console.log(file);
      const imgs = ref(storage, `images/${v4()}`);

      // Uploading the selected image file to Firebase storage
      uploadBytes(imgs, file).then((xyz) => {
        console.log(xyz, "imgs");

        // Retrieving the download URL for the uploaded image
        getDownloadURL(xyz.ref).then((val) => {
          console.log(val);
          img.push(val);
          console.log(img);
        });
      });
    }
    console.log(img);
    console.log("finish");
  };
  // Function to fetch data from the Firestore database
  const fetch = async () => {
    const abc = await getDocs(collection(db, "newimagetext"));
    // console.log(abc)
    // console.log(abc.docs)
    // Mapping the fetched data to a new array with additional id property
    const fetchdata = abc.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    setFetchdata(fetchdata);
    console.log(fetchdata);
    fetchdata.map((value) => {
      imgdata = value.image;
    });
    console.log(imgdata);
  };

  // Running the fetch function once when the component mounts
  useEffect(() => {
    fetch();
  }, []);

  return (
    <div className="App">
      {/* <form>
        <input
          type="text"
          placeholder="text"
          onChange={(e) => setTxt(e.target.value)}
          style={{ border: "2px solid black" }}
          // required
        />
        <h2>Add Image:</h2>
        <input
          type="file"
          onChange={(e) => setF s)}
          required
          multiple
        />
        <button
          type="submit"
          className="btn"
          onClick={handle}
          style={{ width: "auto" }}
          // disabled={isupload ? false:true}
        >
          submit
        </button>
        <button
          type="submit"
          className="btn"
          onClick={add}
          style={{ width: "auto" }}
          // disabled={isupload ? false:true}
        >
          submit2
        </button>
      </form>
      <div>
        {imgdata.map((val) => (
          <div>
            <div>
              <div>
                <img src={val} alt="" style={{ width: "200px" }} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div> */}

    </div>
  );
}

export default Imageadd;
