import React, { useState } from "react";
import List from "../../components/EventList/list";
import Filter from "../../components/Filter/filter";
import Footer from "../../components/Footer/Footer";
import Slider from "../../components/Imageslider/slider";
import Navbar from "../../components/Navbar/Navbar";
import Search from "../../components/Search/search"
import "./event.css";
const Event = () => {
  return (
    <div style={{ backgroundColor: "white" }}>
      <div>
        <Navbar />
      </div>
      <div
        style={{
          backgroundColor: "white",
          paddingBottom: "5px",
        }}
      >
        <div className="row" style={{ width: "99%" }}>
          <div className="col-2" style={{ backgroundColor: "white" }}>
            <div style={{ paddingLeft: "10px" }}>
              <Filter />
            </div>
          </div>
          <div className="col-10" style={{ borderLeft: "1px solid black" }}>
            <Search margin={"20px"}/>
            <div>
              <Slider />
            </div>
            <div className="mt-5">
              <h2
                style={{
                  textAlign: "center",
                }}
              >
                List of all upcoming Events
              </h2>
              <List />
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </div>
  );
};

export default Event;
