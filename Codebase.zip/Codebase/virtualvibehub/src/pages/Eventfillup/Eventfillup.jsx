import { deleteDoc, updateDoc } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { db } from "../../firebase.jsx";
import { addDoc, collection, doc, getDocs } from "firebase/firestore";
import Imageadd from "../Imageadd/Image.jsx";

function Eventfillup() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pno, setPno] = useState("");
  const [fetchdata, setFetchdata] = useState([]);
  const [id, setId] = useState("");
  const add = async (event) => {
    event.preventDefault();
    const adddata = await addDoc(collection(db, "events"), {
      Name: name,
      Email: email,
      Pno: pno,
    });
    if (adddata) {
      alert("data added");
    } else {
      console.log("data not added");
    }
    window.location.reload();
  };
  const fetch = async () => {
    const snapshot = await getDocs(collection(db, "events"));
    const fetchdata = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    setFetchdata(fetchdata);
    console.log(fetchdata);
  };
  useEffect(() => {
    fetch();
  }, []);

  const passdata = async (id) => {
    const matchID = fetchdata.find((data) => {
      return data.id === id;
    });
    console.log(matchID);
    setName(matchID.Name);
    setEmail(matchID.Email);
    setPno(matchID.Pno);
    setId(matchID.id);
  };
  const update = async (event) => {
    event.preventDefault();
    const updateref = doc(collection(db, "events"), id);
    const updatedata = await updateDoc(updateref, {
      Name: name,
      Email: email,
      Pno: pno,
    });
    if (updateref) {
      alert("data updated");
    } else {
      alert("data not updated");
    }
    window.location.reload();
  };
  const del = async (id) => {
    const delref = doc(collection(db, "events"), id);
    try {
      await deleteDoc(delref);
      alert("data deleted");
      window.location.reload();
    } catch (error) {
      alert(error);
    }
  };
  return (
    <div>
      <form>
        <div className="form-container">
          <div className="box"></div>
          <input
            type="text"
            // name="name"
            placeholder="name"
            autoComplete="off"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
          <div className="box"></div>
          <input
            type="text"
            // name="email"
            placeholder="email"
            value={email}
            autoComplete="off"
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />
          <div className="box"></div>
          <input
            type="text"
            // name="pno"
            placeholder="phonenumber"
            value={pno}
            autoComplete="off"
            onChange={(e) => {
              setPno(e.target.value);
            }}
          />
          <br />
          <button type="submit" className="btn" onClick={add}>
            Add
          </button>{" "}
          <br />
          <button type="submit" className="btn" onClick={update}>
            Update
          </button>
        </div>
      </form>
      <div className="database">
        Crud datas
        {fetchdata.map((data) => {
          return (
            <div>
              <h5>{data.Name}</h5>
              <h5>{data.Email}</h5>
              <h5>{data.Pno}</h5>
              <button
                className="btn"
                onClick={() => {
                  passdata(data.id);
                }}
              >
                {" "}
                update
              </button>
              <button
                className="btn"
                onClick={() => {
                  del(data.id);
                }}
              >
                Delete
              </button>
            </div>
          );
        })}
      </div>
</div>
  );
}

export default Eventfillup;
