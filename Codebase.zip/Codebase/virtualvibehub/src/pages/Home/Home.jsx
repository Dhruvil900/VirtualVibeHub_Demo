import React from "react";
import "./home.css";
import Intro from "../../components/HomepageIntro/intro";
import Slider2 from "../../components/Imageslider/slider2";
import Slider from "../../components/Imageslider/slider";
import Services from "../../components/Services/services";
import Footer from "../../components/Footer/Footer";
import Review from "../../components/Reviews/review";
import Navbar from "../../components/Navbar/Navbar";
const Home = () => {
  
  return (
    <div className="home-main">
      <Navbar />
      {/* <div style={{backgroundImage:"linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5))",}}> */}
      <br />
      <Intro />
      {/* </div> */}
      <div style={{backgroundColor:"hsl(192,24%,96%)",paddingTop: "20px",marginTop:"30px",paddingBottom:"40px"}}>

        <div className="container">
          <Slider />
        </div>
      </div>
        <div style={{paddingTop: "20px",paddingBottom:"20px"}}>
          <Services />
        </div>
        
        <div style={{backgroundColor:"hsl(192,24%,96%)",paddingTop: "20px",marginTop:"30px"}}>

        <div className="container" >
          <Review />
        </div>
        </div>
      <div>
        <Footer />
      </div>
    </div>
  );
};

export default Home;
