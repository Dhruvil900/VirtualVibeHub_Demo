import * as React from 'react';
import dayjs from 'dayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';

import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { SingleInputTimeRangeField } from '@mui/x-date-pickers-pro/SingleInputTimeRangeField';

export default function TimeRange() {
  const [value, setValue] = React.useState(() => [
    dayjs('2022-04-17T15:30'),
    dayjs('2022-04-17T18:30'),
  ]);

  // Extracting start and end times in 12-hour AM/PM format
  const startTime = value[0].format('h:mm A'); // Format start time as 'h:mm A'
  const endTime = value[1].format('h:mm A'); // Format end time as 'h:mm A'

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['SingleInputTimeRangeField']}>
        <SingleInputTimeRangeField
          label="Start and End time of event"
          value={value}
          onChange={(newValue) => setValue(newValue)}
        />
      </DemoContainer>

      {/* Displaying the extracted start and end times in 12-hour AM/PM format */}
      <div>
        <p>Start Time: {startTime}</p>
        <p>End Time: {endTime}</p>
      </div>
    </LocalizationProvider>
  );
}
