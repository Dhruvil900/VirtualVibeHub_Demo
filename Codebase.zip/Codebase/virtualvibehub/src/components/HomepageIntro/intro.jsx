import React from "react";
import "./intro.css";
import { Container, Navbar, Nav } from 'react-bootstrap';
import backgroundImage from "../../assets/1.png"; // Import your image

function Intro() {
  return (
    <div className="intro-container" style={{backgroundColor:"white",color:"black"}}>
      <Container>
        <div className="row align-items-center">
          {/* Picture on the left */}
          <div className="col-md-6">
            <div className="hero-content">
              <h1 className="hero-title" style={{fontFamily:"poppins"}}>Welcome to VirtualVibeHub</h1>
              <p className="hero-description">
                VirtualVibeHub is an innovative online event platform that revolutionizes online gatherings by seamlessly integrating interactive features and immersive environments. Showcase your talent, engage with attendees, and explore dynamic digital spaces.
              </p>
              <div className="hero-buttons">
                <button className="textstart">Get Started</button>
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <img src={backgroundImage} alt="Website" className="img-fluid hero-image" />
          </div>
          {/* Text on the right */}
        </div>
      </Container>
    </div>
  );
}

export default Intro;
