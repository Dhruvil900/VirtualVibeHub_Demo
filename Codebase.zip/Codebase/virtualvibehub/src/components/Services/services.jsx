import React from "react";
import "./services.css";
import pic1 from "../../assets/mail-notification.jpg"
import pic2 from "../../assets/rewatch.png"
import pic3 from "../../assets/network.jpg"
import pic4 from "../../assets/virtual.jpg"
import Cardstyle from "../Card/card";
const details=[{
  image:pic1,
  name:"Get notified by Mails",
  des:"We will send you a mail when there is an upcoming events that you have booked.In email you will get everything regarding the event."
  },{
    image:pic2,
  name:"Rewatch your last events",
  des:"With this service you can rewatch your last events that you have completed or even if you have missed it."
  },{
    image:pic3,
  name:"Increase you networking",
  des:"During live event  you can   intereact with other participants and network with them. You can also share your thoughts with other participants.Can take parts in different quizes and"
  },{
    image:pic4,
  name:"Virtual Space",
  des:"You can enjoy youe event in live virtual space just like the physical location. You will be able to see and interact with other participants."
  }]
function Services() {
  return (
    <div className="container mt-4">
      <h1 style={{color:"black"}}>Our Services</h1>
      <div
        className="event-container mx-2"
        style={{ marginTop: "20px",display:"flex", justifyContent: "space-between" }}
      >{details.map((data)=>
      {return(
        <Cardstyle image={data.image} title={data.name} des={data.des} />

      )})}
      </div>
    </div>
  );
}

export default Services;
