import React, { useState } from "react";
import "./navbar.css";
import logo from "../../assets/logo.png";
import User1 from "../../assets/user.png";
import User2 from "../../assets/user_dark.png";
import { Link } from "react-router-dom";
const Navbar = ({ lgn }) => {
  var textforuser;
  // const [textforuser, Settextforuser] = useState("");
  const [userlogo, Setuserlogo] = useState(User1);
  if (localStorage.getItem("signinemail") === null) {
    textforuser = "login";
  } else {
    textforuser = "account";
  }
  return (
    <div className="navbar">
      <Link to="/">
        <img
          src={logo}
          alt="logo"
          className="Logo"
          style={{ width: "90px", height: "70px" }}
        />
      </Link>
      <ul>
        <li className="text">
          <Link to="/" className={`link ${lgn}`}>
            Home
          </Link>
        </li>
        <li className="text">
          <Link to="/event" className={`link ${lgn}`}>
            Events
          </Link>
        </li>
        <li className="text">
          <Link to="/virtual_space" className={`link ${lgn}`}>
            Virtual Space
          </Link>
        </li>
        <li className="text">
          <Link to="/contact" className={`link ${lgn}`}>
            Contact US
          </Link>
        </li>
        <li className="text">
          <Link to="/about" className={`link ${lgn}`}>
            About Us
          </Link>
        </li>
        <li className={`dropdownlogo ${lgn}`}>
          <button
            class=" btn dropdown-toggle"
            type="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
            onMouseEnter={() => Setuserlogo(User2)}
            onMouseLeave={() => Setuserlogo(User1)}
            className="loginbtn"
          >
            <img src={userlogo} alt="" className="userlogo" />
          </button>
          <div
            class="dropdown-menu"
            aria-labelledby="dropdownMenuButton"
            style={{ minWidth: "110px" }}
          >
            <Link
              to={textforuser === "login" ? "/login" : "/Attendeedashboard"}
              className="dropdown-item "
              style={{ color: "black", textDecoration: "none" }}
            >
              {textforuser}
            </Link>
          </div>
        </li>
      </ul>
    </div>
  );
};

export default Navbar;
