import * as React from 'react';
import "../Card/card.css";
// import Card from '@mui/material/Card';

import Card from 'react-bootstrap/Card';
function Cardstyle({image,title,des}) {
  return (
    <Card style={{ width: '18rem' }} className="card">
      <div style={{display:"flex",justifyContent:"center"}}>

      <Card.Img variant="top" src={image} className="mt-2" style={{ height: "200px",width:"15rem",alignItems:"center",display:"flex" }}/>
      </div>
      <Card.Body>
        <Card.Title style={{fontSize:"20px",font:"bolder"}}>{title}</Card.Title>
        <Card.Text>
          {des}
        </Card.Text>
      </Card.Body>
      
    </Card>
  );
}

export default Cardstyle;