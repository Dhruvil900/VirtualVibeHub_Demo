import React from "react";
import "./slider.css";
import Card from "../Card/card";
import { Carousel, Overlay } from "react-bootstrap";
const data = [
  {
    image: "https://picsum.photos/200/300",
    name: "Learn python programming throght competition.",
    description:
      " Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi enim saepe accusantium repudiandae itaque soluta, maiores dolores vitae amet explicabo beatae, eligendi praesentium tenetur, adipisci ducimus voluptatem maxime assumenda molestiae.",
  },

  {
    image: "https://picsum.photos/200/400",
    name: "learn react and node js",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, quidem dignissimos ut asperiores repellat ipsam rerum nisi magni, officiis consectetur reprehenderit! Veniam quae nostrum libero, laborum cumque aliquid corrupti consectetur."
  },
  {
    image: "https://picsum.photos/200/500",
    name: "Learn how to grow your buisness",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, quidem dignissimos ut asperiores repellat ipsam rerum nisi magni, officiis consectetur reprehenderit! Veniam quae nostrum libero, laborum cumque aliquid corrupti consectetur.",
  },
  {
    image: "https://picsum.photos/200/600",
    name: "Learn new IT technologies",
    description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, quidem dignissimos ut asperiores repellat ipsam rerum nisi magni, officiis consectetur reprehenderit! Veniam quae nostrum libero, laborum cumque aliquid corrupti consectetur.",
  },
];
function Slider() {
  return (
    <div className="App">
      <h1 className="heading">Featured and Upcoming events</h1><br />
      <hr />
      <Carousel style={{ transition: "0.8s",
  border: "2px solid #29485b",
  borderRadius: "5px" }}>
        {data.map((item) => (
          <Carousel.Item>
            <div>

            <img className="imageclass " src={item.image} alt={item.name} />
            </div><div>

            <Carousel.Caption style={{ marginLeft: "55px"}}>
              <h3 className="text-black">{item.name}</h3>
              <p className="text-black">{item.description}</p>
              <button className="buttonview">View</button>
            </Carousel.Caption>
            </div>
          </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
}

export default Slider;
