const eventcatagory = ["coding", "buisness", "design", "marketing","photography","music"];
