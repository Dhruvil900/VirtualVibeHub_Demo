import React from "react";
import "./filter.css";
import Range from "../Range/Range";
import DateRange from "../DateRange/daterange";
import Category from "../Category/category";
import Rangemem from "../Rangemember/Range";
import Eventtype from "../Event_type/eventtype";
function Filter() {
  return (
    <div className="mainfilter">
      <div>
        <h3>Filter</h3>
      </div>
      <div>
        <br />
        <h5>Filter events by Price</h5>
        <div className="rangebyprice">
          <Range />
        </div>
      </div>
      <br />
      <div>
        <h5>Filter events by Date</h5>
        <div className="daterange">
          <DateRange />
        </div>
      </div>
      <br />
      <div>
        <h5>Filter events by category</h5>
        <div className="category">
          <Category />
        </div>
      </div>
      <br />
        <h5>Filter events by Event Type</h5>
      <div className="eventtype">
        <Eventtype />
      </div>
      <div className="rangebymem">
        Filter Events by No. of participants
        <Rangemem />
      </div>
      <br />
      <div className="text-end">
        <button className="btn" style={{ width: "80px" }}>
          Filter
        </button>
      </div>
    </div>
  );
}

export default Filter;
