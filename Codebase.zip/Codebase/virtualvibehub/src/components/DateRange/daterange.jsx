import * as React from 'react';
import dayjs from 'dayjs';
import { DemoContainer, DemoItem } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';

import { DatePicker } from '@mui/x-date-pickers/DatePicker';
const date=new Date();
console.log(date)
const year=date.getFullYear()  
const month=date.getMonth()+1
const day=date.getDate()
console.log(month)
const date1=[month,day,year].join('/')
console.log(date1)
export default function DateRange() {
  const [value, setValue] = React.useState(
    dayjs(date1),
  );

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DateRangePicker', 'DateRangePicker']}>
        
        <DemoItem label="" component="DateRangePicker">
          <DatePicker
            value={value}
            onChange={(newValue) => setValue(newValue)}
          />
        </DemoItem>
      </DemoContainer>
    </LocalizationProvider>
  );
}
