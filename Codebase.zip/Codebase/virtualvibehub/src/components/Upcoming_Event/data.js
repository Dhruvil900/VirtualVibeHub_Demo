export const data = [
  {
    date: "22nd january 2024",
    time: "3:00-4:00 PM",
    title: "Pyhton programming",
    participants: "120",
  },
  {
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },
  {
    date: "19th april 2024",
    time: "3:00-4:00 PM",
    title: "php programming",
    participants: "90",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },{
    date: "12th march 2024",
    time: "3:00-4:00 PM",
    title: "Java programming",
    participants: "10",
  },
];
