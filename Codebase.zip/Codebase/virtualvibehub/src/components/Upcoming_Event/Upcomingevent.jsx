import React from "react";
import { data } from "./data";
function Upcomingevent() {
  return (
    <div className="container" style={{ height: "72vh", overflow: "auto" }}>
      {data.map((data) => {
        return (
          <div>
            <h6>{data.date + "" + data.time}</h6>
            <h2>{data.title}</h2>
            <h6>Total participants: {data.participants}</h6>
            <button className="btn" style={{ width: "auto" }}>
              View
            </button>
            <br />
            <br />
            <hr />
          </div>
        );
      })}
    </div>
  );
}

export default Upcomingevent;
