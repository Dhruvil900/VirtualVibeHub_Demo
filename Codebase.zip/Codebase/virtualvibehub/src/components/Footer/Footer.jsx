import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./footer.css";
import { Link } from "react-router-dom";
import logo from "../../assets/logo.png";
import facebook from "../../assets/facebook.png";
import instagram from "../../assets/instagram.png";
import twitter from "../../assets/twitter.png";
import linkdin from "../../assets/linkdin.png";
import youtube from "../../assets/youtube.png";
const Footer = () => {
  let colortheme = localStorage.getItem("current_theme");
  return (
    <div className="footer">
      <div className="container-fluid">
        <div className="row">
          <div className="col-3" style={{ padding: "20px 0px 20px",paddingLeft:"20px" }}>
            <img
              src={logo}
              alt=""
              style={{ width: "90px", height: "70px", marginTop: "15px" }}
            />
            <h5>VirtualVibeHub</h5>
            <div >
              <p
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                VirtualVibeHub is a online event platform which bridge the gap
                between physical event and virtual event by providing the same
                experience as physical event in online.
              </p>
            </div>
          </div>
          <div className="col-6" style={{ padding: "20px 0px 20px" }}>
            <div className="row" style={{ marginTop: "30px" }}>
              <div className="col-6" >
                <div style={{ paddingLeft: "150px" }}>
                  <h5 style={{ textDecoration: "underline" }}>Quick Links</h5>
                  <Link to="/" className="link">
                    Home
                  </Link>
                  <br />
                  <Link to="/event" className="link">
                    Events
                  </Link>
                  <br />
                  <Link to="/virtual_space" className="link">
                    Virtual Space
                  </Link>
                  <br />
                </div>
              </div>
              <div className="col-6">
                <div style={{ paddingRight: "100px" }}>
                  <h5 style={{ textDecoration: "underline" }}>Usefull Pages</h5>
                  <Link to="/contact" className="link">
                    Contact US
                  </Link>
                  <br />
                  <Link to="/login" className="link">
                    Login & Register
                  </Link>
                  <br />
                  <Link to="/about" className="link">
                    About
                  </Link>
                  <br />
                </div>
              </div>
            </div>
            <div
              className="row"
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop:"30px"
              }}
            >
              Follow us on Social Networks
              <div className="icons-list">
                <img src={facebook} alt="" className="social-icon" />
                <img src={instagram} alt="" className="social-icon" />
                <img src={twitter} alt="" className="social-icon" />
                <img src={linkdin} alt="" className="social-icon" />
                <img src={youtube} alt="" className="social-icon" />
              </div>
            </div>
          </div>
          <div className="col-3" style={{ padding: "20px 0px 20px",paddingRight:"20px" }}>
            <h5 style={{ marginTop: "15px" }}>Get in touch</h5>
            <h6 style={{ marginBottom: "-7px" }}>
              Don't miss any news and updates. Get in touch with us
            </h6>{" "}
            <br />
            <input
              type="email"
              placeholder="Enter your email"
              name="email"
              className="form-control"
            />{" "}
            <br />
            <button className="sub-btn">Subscribe</button>
          </div>
        </div>
        <hr />
        <p className="text-center">&copy; 2024 All Rights Reserved</p>
      </div>
    </div>
  );
};
export default Footer;
