import { useState } from "react";

const Input = ({value, title, name, color }) => {
  const [itemcatagory, setItem] = useState("");
    localStorage.setItem("Category", itemcatagory);
    return (
      <label className="sidebar-label-container">
        <input type="radio" value={value} name={name} onClick={(e) =>setItem(e.target.value) }/>
        <span className="checkmark"  style={{ backgroundColor: color }}></span>
        {title}
      </label>
    );
  };
  
  export default Input;