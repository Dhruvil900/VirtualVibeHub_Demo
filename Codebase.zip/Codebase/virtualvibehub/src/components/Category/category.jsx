import "./category.css";
import Input from "./input";
const data = ["All", "programming", "design", "music", "photography"];
function Category() {
  return (
    <div>
      <div>
        {data.map((item) => {
          return <Input  value={item} title={item} name="test" />;
        })}
      </div>
    </div>
  );
}

export default Category;
