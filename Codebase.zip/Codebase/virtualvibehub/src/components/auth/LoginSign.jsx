import React, { useEffect } from "react";
import * as Components from "./Components";
import "./login.css";
import { auth, db } from "../../firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from "firebase/auth";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Spinner } from "react-bootstrap";
import { getRoles } from "@testing-library/react";
function Signinup() {
  const [signinemail, setSigninemail] = useState("");
  const [signinpassword, setSigninpassword] = useState("");
  const [signupemail, setSignupemail] = useState("");
  const [signIn, toggle] = React.useState(true);
  const [showerror, setShowerror] = useState("");
  const [signuperror, setSignuperror] = useState("");
  const homenav = useNavigate();
  let useruid;
  const [loader, setLoader] = useState(false);
  const [signinData, setSigninData] = useState({
    email: "",
    password: "",
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [error, setError] = useState([]);
  const [Userrole, setUserrole] = useState(null);
  const [signinerror, setSigninError] = useState([]);
  // const roles = () => {
  //   auth.onAuthStateChanged((user) => {
  //     if (user) {
  //       localStorage.setItem("useruid", user.uid);
  //     } else {
  //       console.log("no user");
  //     }
  //   });
  // };
  // useEffect(() => {
  //   roles();
  // }, []);

  const updatedb = async () => {
    const ref = db.collection("roles").doc("Attendee");
    try {
      await ref.update({
        uid: useruid,
      });
    } catch (err) {
      console.log(err);
    }
    console.log(useruid);
    const userref = db.collection("username").doc(useruid);
    try {
      await userref.set({
        username: formData.name,
      });
    } catch (e) {
      console.log(e);
    }
  };
  let rolesarray = ["Admin", "Attendee", "Superadmin", "Speaker"];
  const getrole = async () => {
    try {
      for (const element of rolesarray) {
        const docref = db.collection("roles").doc(element);
        const snapshot = await docref.get();
        localStorage.setItem("userrole", element);
        const data = snapshot.data();
        const uid = data.uid;
        console.log(element, useruid);
        const tof = uid.includes(useruid);
        console.log(tof);
        // Check if data exists and contains uid
        if (uid.includes(useruid)) {
          localStorage.setItem("userrole", element);
          if (element === "Admin" || element === "Superadmin") {
            homenav("/admin-dashboard");
          } else homenav("/Attendeedashboard");
          break; // Exit loop once user role is found
        }
      }
    } catch (error) {
      console.error("Error getting user role:", error);
    }
  };

  const signupfunction = (e) => {
    e.preventDefault();
    let email_pattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,6}$/;
    let password_pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z0-9]{8,}$/;
    let errors = [];
    const { name, email, password } = formData;
    if (name.trim() === "") {
      errors.push("#emptyName");
    }
    if (email === "") {
      errors.push("#emptyEmail");
    } else if (email !== "" && !email_pattern.test(email)) {
      errors.push("#invalidEmail");
    }
    if (password === "") {
      errors.push("#emptyPassword");
    } else if (password !== "" && !password_pattern.test(password)) {
      errors.push("#invalidPassword");
    }

    if (errors.length > 0) {
      setError(errors);
    } else {
      setError([]);
      setLoader(true);

      createUserWithEmailAndPassword(auth, formData.email, formData.password)
        .then((user) => {
          localStorage.setItem("signinemail", signupemail);
          useruid = user.user.uid;
          localStorage.setItem("userrole", "Attendee");
          homenav("/user-dashboard");
        })
        .then(() => {
          updatedb();
        })
        .catch((error) => {
          setSignuperror(error.message);
          setLoader(false);
        });
    }
  };

  const signinfunction = (e) => {
    e.preventDefault();
    let errors = [];
    const { email, password } = signinData;
    if (email === "") {
      errors.push("#emptyEmail");
    }
    if (password === "") {
      errors.push("#emptyPassword");
    }
    if (errors.length > 0) {
      setSigninError(errors);
    } else {
      setSigninError([]);
      setLoader(true);
      signInWithEmailAndPassword(auth, signinData.email, signinData.password)
        .then((user) => {
          useruid = user.user.uid;
          localStorage.setItem("signinemail", signinData.email);
          localStorage.setItem("useruid", useruid);
          setTimeout(() => {
            setLoader(false);
          }, 3000);
        })
        .then(() => {
          getrole();
        })
        .catch((error) => {
          setShowerror("!Inavlid Username or Password...Please try again");
          setLoader(false);
        });
    }
  };
  // function handleValidation(formData){
  // formData.preventDefault()
  // setErrors(Validation(formData))
  // };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    console.log(formData);
  };
  const handleSignin = (e) => {
    const { name, value } = e.target;
    setSigninData({
      ...signinData,
      [name]: value,
    });
    console.log(signinData);
  };

  return (
    <div className="loginsign">
      <Components.Container>
        <Components.SignUpContainer signinIn={signIn}>
          <Components.Form onSubmit={signupfunction}>
            <Components.Title>Create Account</Components.Title>
            <Components.Input
              type="text"
              name="name"
              placeholder="Name"
              // value={formData.name}
              onChange={handleChange}
            />
            {error.includes("#emptyName") && (
              <p style={{ color: "red" }}>Name is required!</p>
            )}
            <Components.Input
              type="email"
              name="email"
              placeholder="Email"
              // value={formData.email}
              onChange={handleChange}
            />
            {error.includes("#emptyEmail") && (
              <p style={{ color: "red" }}>Email is required!</p>
            )}
            {error.includes("#invalidEmail") && (
              <p style={{ color: "red" }}>Invalid email format!</p>
            )}
            <Components.Input
              type="password"
              name="password"
              placeholder="Password"
              // value={formData.password}
              onChange={handleChange}
            />
            {error.includes("#emptyPassword") && (
              <p style={{ color: "red" }}>Password is required!</p>
            )}
            {error.includes("#invalidPassword") && (
              <p style={{ color: "red" }}>
                Password must contain atleast 1 uppercase, 1 lowercase, 1 number
                and minimum 8 characters long.{" "}
              </p>
            )}
            <br />
            <h6 style={{ color: "red" }}>{signuperror}</h6>
            <Components.Button type="submit" disabled={loader}>
              {loader && (
                <Spinner
                  size="sm"
                  style={{
                    marginRight: "5px",
                  }}
                ></Spinner>
              )}
              Sign Up
            </Components.Button>
            {/* <Link to="/image">
              <button className="btn">submit</button>
            </Link> */}
          </Components.Form>
        </Components.SignUpContainer>

        <Components.SignInContainer signinIn={signIn}>
          <Components.Form
            onSubmit={(e) => {
              signinfunction(e);
            }}
          >
            <Components.Title>Sign in</Components.Title>
            <Components.Input
              type="email"
              name="email"
              placeholder="Email"
              // value={signinData.email}
              onChange={handleSignin}
            />
            {signinerror.includes("#emptyEmail") && (
              <p style={{ color: "red" }}>Email is required!</p>
            )}
            <Components.Input
              type="password"
              name="password"
              placeholder="Password"
              // value={signinData.password}
              onChange={handleSignin}
            />
            {signinerror.includes("#emptyPassword") && (
              <p style={{ color: "red" }}>Password is required!</p>
            )}
            <h6 style={{ color: "red" }}>{showerror}</h6>
            <Components.Anchor href="#">
              Forgot your password?
            </Components.Anchor>
            <Components.Button type="submit" disabled={loader}>
              {loader && (
                <Spinner
                  size="sm"
                  style={{
                    marginRight: "5px",
                  }}
                ></Spinner>
              )}
              Sign In
            </Components.Button>
          </Components.Form>
        </Components.SignInContainer>

        <Components.OverlayContainer signinIn={signIn}>
          <Components.Overlay signinIn={signIn}>
            <Components.LeftOverlayPanel signinIn={signIn}>
              <Components.Title>Welcome Back!</Components.Title>
              <Components.Paragraph>
                Enter your email and Password to explore new event and keep
                updated yourself by connect with new people and technology.
              </Components.Paragraph>
              <Components.GhostButton onClick={() => toggle(true)}>
                Sign In
              </Components.GhostButton>
            </Components.LeftOverlayPanel>

            <Components.RightOverlayPanel signinIn={signIn}>
              <Components.Title>Hello, Friend!</Components.Title>
              <Components.Paragraph>
                Enter Your details and know more about upcoming events and new
                trending technologies and many more features.
              </Components.Paragraph>
              <Components.GhostButton onClick={() => toggle(false)}>
                Sigin Up
              </Components.GhostButton>
            </Components.RightOverlayPanel>
          </Components.Overlay>
        </Components.OverlayContainer>
      </Components.Container>
    </div>
  );
}

export default Signinup;
