import React from "react";
import "./review.css";
import { Carousel } from "react-bootstrap";
import pic1 from "../../assets/human.png";
import pic2 from "../../assets/man.png";
import pic3 from "../../assets/profile.png";
import CenterMode from "../ReviewCard/Reviewcard";
const data = [
  {
    image: pic1,
    name: "Stefan Robartz",
    description:
      "I recently had the pleasure of working with a web development company to create my company's new website, and I have been beyond impressed with the entire experience. From the initial consultation to the final launch, they exceeded my expectations in every aspect",
  },
  {
    image: pic2,
    name: "Stefan Robartz",
    description:
      "One of the things that stood out to me was their attention to detail. They took the time to understand my brand and vision for the website, and every element was carefully crafted to align with that. The end result was a stunning website that truly represents my business and its values.    ",
  },
  {
    image: pic3,
    name: "Stefan Robartz",
    description:
      "I was also impressed with their technical expertise. They were able to create a website that not only looks amazing but also functions seamlessly. They incorporated all the necessary features and integrations I requested and even provided suggestions for additional enhancements that I hadn't thought of.  ",
  },
];
function Review() {
  return (
    <div className="reviews">
      <h1 style={{ textAlign: "center", color: "black" }}>Testimonials</h1>
      <hr />
      <Carousel
        style={{
          transition: "0.8s",
          border: "2px solid #29485b",
          borderRadius: "5px",
        }}
      >
        {data.map((item) => (
          <Carousel.Item>
            <img
              className="imageclass "
              src={item.image}
              alt={item.name}
              style={{ height: "200px", width: "200px" }}
            />
            <Carousel.Caption style={{ marginLeft: "15px" }}>
              <h3 className="text-black">{item.name}</h3>
              <p className="text-black">{item.description}</p>
            </Carousel.Caption>
          </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
}

export default Review;
