import { useState } from "react";

const Input = ({value, title, name, color }) => {
  const [itemcatagory, setItem] = useState("");
    localStorage.setItem("event-type", itemcatagory);
    return (
      <label className="sidebar-label-container">
        <input type="checkbox" value={value} name={name} onClick={(e) =>setItem(e.target.value) }/>
        <span className="checkmark"  style={{ backgroundColor: color }}></span>
        {title}
      </label>
    );
  };
  
  export default Input;