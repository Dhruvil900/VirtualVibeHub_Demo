import React from "react";
import Input from "./input";
const data = ["conference","webinar","workshop","meeting"];


function Eventtype() {
  return (
    <div>
      <div>
        {data.map((item) => {
          return <Input value={item} title={item} name="test" />;
        })}
      </div>
    </div>
  );
}

export default Eventtype;
