import React from 'react'

function Rangepart() {
  return (
    <div>Rangepart</div>
  )
}

export default Rangepart