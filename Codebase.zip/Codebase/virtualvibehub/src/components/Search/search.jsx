import React from "react";

function Search({margin}) {
  return (
    <form class="d-flex" role="search" style={{marginTop:`${margin}`}}>
      <input
        class="form-control"
        type="search"
        placeholder="Search"
        aria-label="Search"
        style={{ marginRight: "15px", border: "1px solid black" }}
      />
      <button class="btn btn-outline-success" type="submit">
        Search
      </button>
    </form>
  );
}

export default Search;
