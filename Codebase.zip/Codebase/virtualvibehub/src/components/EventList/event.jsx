import React from "react";
import { Link } from "react-router-dom";

function Event({ pic, name, des, date, time, id }) {
  const xyz = 123;
  return (
    <div style={{ height: "100%" }}>
      <div
        className="row "
        style={{
          borderBottom: "1px solid black",
          paddingBottom: "15px",
          overflow: "hidden",
        }}
      >
        <div
          className="col-sm-2"
          style={{ display: "flex", alignItems: "center" }}
        >
          <div
            style={{
              width: "auto",
              display: "flex",
              justifyContent: "center",
              objectFit: "contain",
            }}
          >
            <img
              src={pic}
              class="img-fluid"
              alt="image"
              style={{ height: "150px", borderRadius: "8px", width: "200px" }}
            />
          </div>
        </div>
        <div className="col-sm-10 text-center ">
          <div className="row-sm-2  ">
            <text
              style={{
                fontWeight: "bold",
                fontSize: "18px",
                textDecoration: "underline",
              }}
            >
              Event Name :-{" "}
            </text>
            {name}
          </div>
          <h5
            style={{
              fontWeight: "bold",
              fontSize: "18px",
              textDecoration: "underline",
            }}
          >
            Details :-
          </h5>
          <div
            className="row-sm-9  "
            style={{ height: "100px", overflow: "auto" }}
          >
            {des}
          </div>
          <div className="row-sm-1">
            <text
              style={{
                fontWeight: "bold",
                fontSize: "18px",
                textDecoration: "underline",
              }}
            >
              Date and time :-{" "}
            </text>
            {date} {"    "} &ensp;{time}
            <div style={{ right: "0" }}>
              <Link to="/details" state={id}>
                <button
                  className="btn"
                  style={{ width: "100px", marginTop: "5px" }}
                >
                  View more
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Event;
