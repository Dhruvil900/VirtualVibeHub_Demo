import { collection, getDocs } from "firebase/firestore";
import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { db } from "../../firebase";
import Event from "./event";
import "./list.css";
function List() {
  const [fetchdata, setFetchdata] = useState([]);
  const fetch = async () => {
    const snapshot = await getDocs(collection(db, "events"));
    const fetchdata = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    setFetchdata(fetchdata);
    console.log(fetchdata);
  };
  useEffect(() => {
    fetch();
  }, []);
  return (
    <div className=" container mt-4 list">
      {fetchdata.map((item) => {
        let stime=item.StartTime;
        let etime=item.EndTime;
        let time=stime+" - "+etime;
        return (
         
          <Event
            pic={item.MainImage}
            name={item.EventName}
            des={item.EventDescriptionShort}
            date={item.Date}
            time={time}
            id={item.id}
          />
        );
      })}
    </div>
  );
}

export default List;
