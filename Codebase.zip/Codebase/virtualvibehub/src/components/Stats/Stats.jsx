import React from "react";
import graph from "../../assets/graph.png";
import graph2 from "../../assets/Linebar.png";
import calender from "../../assets/calender.jpg";

function Stats() {
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          paddingTop: "10px",
          boxShadow: " 0 5px 20px 0 hsla(219,56%,21%,0.1) ",
        }}
      >
        {" "}
        <img src={graph} alt="" style={{ width: "350px" }} />
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginTop: "10px",
          boxShadow: " 0 5px 20px 0 hsla(219,56%,21%,0.1) ",
        }}
      >
        {" "}
        <img src={graph2} alt="" style={{ width: "350px" }} />{" "}
      </div>
      <div>
        <h6>Calender</h6>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            marginTop: "10px",
            boxShadow: " 0 5px 20px 0 hsla(219,56%,21%,0.1) ",
          }}
        >
            <img src={calender} alt="" style={{width:"300px"}} />
        </div>
      </div>
    </div>
  );
}

export default Stats;
